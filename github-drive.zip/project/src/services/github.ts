const GITHUB_API_BASE = 'https://api.github.com';
const REPO_OWNER = '0vx200';
const REPO_NAME = 'public-storage';
const ACCESS_TOKEN = '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';

const headers = {
  'Authorization': `token ${ACCESS_TOKEN}`,
  'Content-Type': 'application/json',
  'Accept': 'application/vnd.github.v3+json'
};

export class GitHubService {
  static async getFiles(path = ''): Promise<any> {
    const url = `${GITHUB_API_BASE}/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}`;
    
    try {
      const response = await fetch(url, { headers });
      if (!response.ok) {
        throw new Error(`GitHub API error: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching files:', error);
      throw error;
    }
  }

  static async uploadFile(path: string, content: string, message = 'Upload file'): Promise<any> {
    const url = `${GITHUB_API_BASE}/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}`;
    
    try {
      const response = await fetch(url, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message,
          content,
          branch: 'main'
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Upload failed: ${response.status} - ${errorData.message || 'Unknown error'}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  }

  static async deleteFile(path: string, sha: string, message = 'Delete file'): Promise<any> {
    const url = `${GITHUB_API_BASE}/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}`;
    
    try {
      const response = await fetch(url, {
        method: 'DELETE',
        headers,
        body: JSON.stringify({
          message,
          sha,
          branch: 'main'
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Delete failed: ${response.status} - ${errorData.message || 'Unknown error'}`);
      }
      
      // GitHub returns 200 for successful deletion
      if (response.status === 200) {
        return await response.json();
      }
      
      return { success: true };
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }

  static async deleteFolder(path: string): Promise<any> {
    try {
      // Get all files in the folder first
      const files = await this.getFiles(path);
      
      if (!Array.isArray(files)) {
        throw new Error('Invalid folder structure');
      }

      // Delete all files in the folder recursively
      const deletePromises = files.map(async (file) => {
        if (file.type === 'dir') {
          // Recursively delete subdirectories
          return this.deleteFolder(file.path);
        } else {
          // Delete individual files
          return this.deleteFile(file.path, file.sha, `Delete ${file.name}`);
        }
      });

      await Promise.all(deletePromises);
      return { success: true, message: 'Folder deleted successfully' };
    } catch (error) {
      console.error('Error deleting folder:', error);
      throw error;
    }
  }

  static async createFolder(path: string): Promise<any> {
    // GitHub doesn't have folders, so we create a .gitkeep file
    const keepFile = `${path}/.gitkeep`;
    return this.uploadFile(keepFile, '', `Create folder ${path}`);
  }
}