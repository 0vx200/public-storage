import React, { useState } from 'react';
import { MoreVertical, Download, Trash2, Eye, ExternalLink } from 'lucide-react';
import { getFileIcon, formatFileSize, isImageFile } from '../utils/fileUtils';

interface FileItemProps {
  file: any;
  viewMode: 'grid' | 'list';
  onNavigate: (path: string) => void;
  onDelete: (file: any) => void;
  onPreview: (file: any) => void;
}

export const FileItem: React.FC<FileItemProps> = ({
  file,
  viewMode,
  onNavigate,
  onDelete,
  onPreview
}) => {
  const [showActions, setShowActions] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const IconComponent = getFileIcon(file.name, file.type === 'dir');
  const isDirectory = file.type === 'dir';
  const isImage = isImageFile(file.name);

  const handleClick = () => {
    if (isDirectory) {
      onNavigate(file.path);
    } else {
      onPreview(file);
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (file.download_url) {
      window.open(file.download_url, '_blank');
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    const confirmMessage = isDirectory 
      ? `Are you sure you want to delete the folder "${file.name}" and all its contents?`
      : `Are you sure you want to delete "${file.name}"?`;
    
    if (window.confirm(confirmMessage)) {
      setIsDeleting(true);
      try {
        await onDelete(file);
      } catch (error) {
        console.error('Delete failed:', error);
      } finally {
        setIsDeleting(false);
      }
    }
  };

  const handleExternalView = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (file.html_url) {
      window.open(file.html_url, '_blank');
    }
  };

  if (viewMode === 'list') {
    return (
      <div 
        className={`flex items-center space-x-3 sm:space-x-4 p-3 sm:p-4 hover:bg-gray-50 rounded-xl cursor-pointer group transition-all duration-200 ${
          isDeleting ? 'opacity-50 pointer-events-none' : ''
        }`}
        onClick={handleClick}
        onMouseEnter={() => setShowActions(true)}
        onMouseLeave={() => setShowActions(false)}
      >
        <IconComponent className={`w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0 ${isDirectory ? 'text-blue-600' : 'text-gray-600'}`} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
          {!isDirectory && (
            <p className="text-xs text-gray-500 mt-1">{formatFileSize(file.size)}</p>
          )}
        </div>
        
        <div className={`flex items-center space-x-1 transition-all duration-200 ${
          showActions ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-2'
        }`}>
          {!isDirectory && isImage && (
            <button
              onClick={(e) => { e.stopPropagation(); onPreview(file); }}
              className="p-1.5 sm:p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200"
              title="Preview"
            >
              <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
            </button>
          )}
          {!isDirectory && (
            <button
              onClick={handleDownload}
              className="p-1.5 sm:p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all duration-200"
              title="Download"
            >
              <Download className="w-3 h-3 sm:w-4 sm:h-4" />
            </button>
          )}
          <button
            onClick={handleExternalView}
            className="p-1.5 sm:p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all duration-200"
            title="View on GitHub"
          >
            <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4" />
          </button>
          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="p-1.5 sm:p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200 disabled:opacity-50"
            title={isDirectory ? "Delete Folder" : "Delete File"}
          >
            <Trash2 className={`w-3 h-3 sm:w-4 sm:h-4 ${isDeleting ? 'animate-pulse' : ''}`} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`bg-white border border-gray-100 rounded-xl sm:rounded-2xl p-3 sm:p-5 hover:shadow-lg hover:border-gray-200 cursor-pointer group transition-all duration-300 hover:-translate-y-1 ${
        isDeleting ? 'opacity-50 pointer-events-none' : ''
      }`}
      onClick={handleClick}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex items-center justify-between mb-3 sm:mb-4">
        <IconComponent className={`w-8 h-8 sm:w-10 sm:h-10 ${isDirectory ? 'text-blue-600' : 'text-gray-600'}`} />
        
        <div className={`transition-all duration-200 ${
          showActions ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
        }`}>
          <div className="flex items-center space-x-1">
            <button
              onClick={handleExternalView}
              className="p-1.5 sm:p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all duration-200"
              title="View on GitHub"
            >
              <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4" />
            </button>
            <button
              onClick={handleDelete}
              disabled={isDeleting}
              className="p-1.5 sm:p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200 disabled:opacity-50"
              title={isDirectory ? "Delete Folder" : "Delete File"}
            >
              <Trash2 className={`w-3 h-3 sm:w-4 sm:h-4 ${isDeleting ? 'animate-pulse' : ''}`} />
            </button>
          </div>
        </div>
      </div>
      
      <h3 className="text-xs sm:text-sm font-semibold text-gray-900 mb-2 truncate" title={file.name}>
        {file.name}
      </h3>
      
      {!isDirectory && (
        <p className="text-xs text-gray-500 mb-3 sm:mb-4">{formatFileSize(file.size)}</p>
      )}

      {!isDirectory && (
        <div className={`flex items-center space-x-1 sm:space-x-2 transition-all duration-300 ${
          showActions ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
        }`}>
          {isImage && (
            <button
              onClick={(e) => { e.stopPropagation(); onPreview(file); }}
              className="flex-1 flex items-center justify-center space-x-1 py-1.5 sm:py-2 px-2 sm:px-3 text-xs font-medium bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-all duration-200"
            >
              <Eye className="w-3 h-3" />
              <span className="hidden sm:inline">Preview</span>
            </button>
          )}
          <button
            onClick={handleDownload}
            className="flex-1 flex items-center justify-center space-x-1 py-1.5 sm:py-2 px-2 sm:px-3 text-xs font-medium bg-green-50 hover:bg-green-100 text-green-700 rounded-lg transition-all duration-200"
          >
            <Download className="w-3 h-3" />
            <span className="hidden sm:inline">Download</span>
          </button>
        </div>
      )}
    </div>
  );
};