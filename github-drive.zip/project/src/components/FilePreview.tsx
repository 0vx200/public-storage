import React from 'react';
import { X, Download, ExternalLink } from 'lucide-react';
import { isImageFile } from '../utils/fileUtils';

interface FilePreviewProps {
  file: any;
  isOpen: boolean;
  onClose: () => void;
}

export const FilePreview: React.FC<FilePreviewProps> = ({ file, isOpen, onClose }) => {
  if (!isOpen || !file) return null;

  const isImage = isImageFile(file.name);

  const handleDownload = () => {
    if (file.download_url) {
      window.open(file.download_url, '_blank');
    }
  };

  const handleExternalView = () => {
    if (file.html_url) {
      window.open(file.html_url, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl max-h-[90vh] w-full flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-white">
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-semibold text-gray-900 truncate">{file.name}</h2>
            <p className="text-sm text-gray-500 mt-1">File Preview</p>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <button
              onClick={handleDownload}
              className="p-3 text-gray-600 hover:text-green-600 hover:bg-green-50 rounded-xl transition-all duration-200"
              title="Download"
            >
              <Download className="w-5 h-5" />
            </button>
            <button
              onClick={handleExternalView}
              className="p-3 text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all duration-200"
              title="View on GitHub"
            >
              <ExternalLink className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-3 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-xl transition-all duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 bg-gray-50">
          {isImage && file.download_url ? (
            <div className="flex justify-center items-center h-full">
              <img
                src={file.download_url}
                alt={file.name}
                className="max-w-full max-h-full object-contain rounded-xl shadow-lg bg-white"
                style={{ maxHeight: 'calc(90vh - 200px)' }}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 bg-white rounded-xl p-12">
              <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mb-6">
                <ExternalLink className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Preview not available</h3>
              <p className="text-gray-600 text-center mb-6 max-w-md">
                This file type cannot be previewed in the browser. Download the file to view its contents.
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={handleDownload}
                  className="px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  Download File
                </button>
                <button
                  onClick={handleExternalView}
                  className="px-6 py-3 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200 transition-all duration-200"
                >
                  View on GitHub
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};