import React from 'react';
import { 
  Home, 
  Upload, 
  FolderPlus, 
  Grid3X3,
  List,
  HardDrive,
  X
} from 'lucide-react';

interface SidebarProps {
  currentPath: string;
  viewMode: 'grid' | 'list';
  onNavigate: (path: string) => void;
  onViewModeChange: (mode: 'grid' | 'list') => void;
  onUploadClick: () => void;
  onCreateFolder: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPath,
  viewMode,
  onNavigate,
  onViewModeChange,
  onUploadClick,
  onCreateFolder,
  onToggleCollapse
}) => {
  const menuItems = [
    { icon: Home, label: 'Home', action: () => onNavigate(''), active: currentPath === '' },
    { icon: Upload, label: 'Upload Files', action: onUploadClick, active: false },
    { icon: FolderPlus, label: 'New Folder', action: onCreateFolder, active: false }
  ];

  return (
    <div className="w-72 bg-white border-r border-gray-100 flex flex-col shadow-lg lg:shadow-sm h-full">
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <HardDrive className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">GitHub Drive</h1>
              <p className="text-xs text-gray-500">Cloud Storage</p>
            </div>
          </div>
          <button
            onClick={onToggleCollapse}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-all duration-200 lg:hidden"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 p-4 overflow-y-auto">
        <nav className="space-y-2">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={item.action}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                item.active 
                  ? 'bg-blue-50 text-blue-700 shadow-sm' 
                  : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* View Mode Toggle */}
        <div className="mt-8">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 px-2">
            View Mode
          </h3>
          <div className="flex bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => onViewModeChange('grid')}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-lg text-xs font-medium transition-all duration-200 ${
                viewMode === 'grid' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Grid3X3 className="w-4 h-4" />
              <span>Grid</span>
            </button>
            <button
              onClick={() => onViewModeChange('list')}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-lg text-xs font-medium transition-all duration-200 ${
                viewMode === 'list' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <List className="w-4 h-4" />
              <span>List</span>
            </button>
          </div>
        </div>
      </div>

      {/* Storage Info */}
      <div className="p-4 sm:p-6 border-t border-gray-100">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Storage</span>
            <span className="text-xs text-gray-500">GitHub Repo</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full w-1/3"></div>
          </div>
          <p className="text-xs text-gray-500">Connected to repository</p>
        </div>
      </div>
    </div>
  );
};