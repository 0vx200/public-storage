import React, { useState } from 'react';
import { Waves, ArrowRightLeft, Droplets } from 'lucide-react';
import { networks } from './config/networks';
import { NetworkSelector } from './components/NetworkSelector';
import { WalletButton } from './components/WalletButton';
import { SwapInterface } from './components/SwapInterface';
import { LiquidityInterface } from './components/LiquidityInterface';
import { useWallet } from './hooks/useWallet';

function App() {
  const [currentNetwork, setCurrentNetwork] = useState(networks[0]);
  const [isNetworkSelectorOpen, setIsNetworkSelectorOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'swap' | 'liquidity'>('swap');
  const { switchNetwork } = useWallet();

  const handleNetworkChange = async (network: typeof networks[0]) => {
    setCurrentNetwork(network);
    await switchNetwork(network);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="p-4 sm:p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="bg-gradient-to-br from-cyan-400 to-blue-500 p-2 sm:p-3 rounded-xl shadow-lg">
              <Waves className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-cyan-300">Allswap</h1>
              <p className="text-xs sm:text-sm text-cyan-200/70">Multichain DEX</p>
            </div>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-4">
            <NetworkSelector
              currentNetwork={currentNetwork}
              networks={networks}
              onNetworkChange={handleNetworkChange}
              isOpen={isNetworkSelectorOpen}
              onToggle={() => setIsNetworkSelectorOpen(!isNetworkSelectorOpen)}
            />
            <WalletButton />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-3 sm:px-6 pb-12">
        <div className="max-w-md mx-auto">
          {/* Tab Navigation */}
          <div className="flex bg-slate-800/50 backdrop-blur-sm rounded-xl p-1 mb-6 border border-slate-700/50">
            <button
              onClick={() => setActiveTab('swap')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-lg transition-all duration-300 ease-in-out ${
                activeTab === 'swap'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg transform scale-[1.02]'
                  : 'text-cyan-300 hover:bg-slate-700/50'
              }`}
            >
              <ArrowRightLeft className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="font-medium text-sm sm:text-base">Swap</span>
            </button>
            <button
              onClick={() => setActiveTab('liquidity')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-lg transition-all duration-300 ease-in-out ${
                activeTab === 'liquidity'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg transform scale-[1.02]'
                  : 'text-cyan-300 hover:bg-slate-700/50'
              }`}
            >
              <Droplets className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="font-medium text-sm sm:text-base">Liquidity</span>
            </button>
          </div>

          {/* Interface Container with smooth transition */}
          <div className="relative">
            <div 
              className={`transition-all duration-300 ease-in-out ${
                activeTab === 'swap' 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-4 pointer-events-none absolute inset-0'
              }`}
            >
              <SwapInterface currentNetwork={currentNetwork} />
            </div>
            
            <div 
              className={`transition-all duration-300 ease-in-out ${
                activeTab === 'liquidity' 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-4 pointer-events-none absolute inset-0'
              }`}
            >
              <LiquidityInterface currentNetwork={currentNetwork} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;