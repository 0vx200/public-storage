import { Contract, formatUnits, parseUnits, JsonRpcProvider, BrowserProvider } from 'ethers';
import { Network, Token, SwapQuote } from '../types';
import { ROUTER_ABI, ERC20_ABI, FACTORY_ABI } from '../config/abis';

interface PairReserves {
  reserveA: string;
  reserveB: string;
}

interface LiquidityPosition {
  tokenA: Token;
  tokenB: Token;
  liquidityTokens: string;
  share: number;
  reserveA: string;
  reserveB: string;
  pairAddress: string;
}

// Simple pair ABI for getting reserves
const PAIR_ABI = [
  {
    "inputs": [],
    "name": "getReserves",
    "outputs": [
      {"internalType": "uint112", "name": "_reserve0", "type": "uint112"},
      {"internalType": "uint112", "name": "_reserve1", "type": "uint112"},
      {"internalType": "uint32", "name": "_blockTimestampLast", "type": "uint32"}
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "address", "name": "", "type": "address"}],
    "name": "balanceOf",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "token0",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "token1",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "stateMutability": "view",
    "type": "function"
  }
];

export class ContractService {
  private provider: JsonRpcProvider | BrowserProvider;
  private network: Network;

  constructor(network: Network, provider?: BrowserProvider) {
    this.network = network;
    this.provider = provider || new JsonRpcProvider(network.rpcUrl);
  }

  private getRouterContract(signer?: any) {
    return new Contract(
      this.network.contracts.ROUTER.address,
      ROUTER_ABI,
      signer || this.provider
    );
  }

  private getFactoryContract(signer?: any) {
    return new Contract(
      this.network.contracts.FACTORY.address,
      FACTORY_ABI,
      signer || this.provider
    );
  }

  private getTokenContract(tokenAddress: string, signer?: any) {
    return new Contract(tokenAddress, ERC20_ABI, signer || this.provider);
  }

  private getPairContract(pairAddress: string, signer?: any) {
    return new Contract(pairAddress, PAIR_ABI, signer || this.provider);
  }

  // Helper function to safely parse amounts and handle scientific notation
  private safeParseUnits(amount: string, decimals: number): bigint {
    try {
      // Handle scientific notation by converting to a proper decimal string
      const num = Number(amount);
      if (num === 0) return BigInt(0);
      
      // Check for very small numbers that would cause issues
      if (num < 1e-18) {
        console.warn('Amount too small, returning 0:', amount);
        return BigInt(0);
      }
      
      // Convert to fixed decimal places using exactly the specified decimals
      const fixedDecimalString = num.toFixed(decimals);
      
      // Check if the formatted number is effectively zero
      const formattedNum = Number(fixedDecimalString);
      if (formattedNum === 0 && num !== 0) {
        // The number was too small to represent with the given decimals
        console.warn('Number too small for decimals, returning 0:', amount, 'decimals:', decimals);
        return BigInt(0);
      }
      
      // Remove trailing zeros after the decimal point
      const cleanDecimalString = fixedDecimalString.replace(/\.?0+$/, '');
      
      // If the result is empty or just a decimal point, return 0
      if (!cleanDecimalString || cleanDecimalString === '.') {
        return BigInt(0);
      }
      
      return parseUnits(cleanDecimalString, decimals);
    } catch (error) {
      console.error('Error parsing units:', error, 'Amount:', amount, 'Decimals:', decimals);
      return BigInt(0);
    }
  }

  // Helper function to normalize addresses to proper checksum format
  private normalizeAddress(address: string): string {
    if (address === 'ETH') return address;
    
    // Convert to lowercase to avoid checksum issues
    return address.toLowerCase();
  }

  // Helper function to generate custom logo URL based on token symbol
  private generateTokenLogo(symbol: string): string {
    if (!symbol || symbol.trim() === '') {
      return 'https://via.placeholder.com/40x40/06b6d4/ffffff?text=T';
    }
    
    // Get first character of symbol, uppercase
    const firstChar = symbol.trim().charAt(0).toUpperCase();
    
    // Create a simple but distinctive logo with the first character
    return `https://via.placeholder.com/40x40/06b6d4/ffffff?text=${firstChar}`;
  }

  // Create a network-specific provider to avoid network change errors
  private createNetworkSpecificProvider(): JsonRpcProvider {
    return new JsonRpcProvider(this.network.rpcUrl);
  }

  // Comprehensive ERC20 validation with network isolation
  async isValidERC20Contract(tokenAddress: string): Promise<boolean> {
    try {
      if (tokenAddress === 'ETH') return true;
      
      const normalizedTokenAddress = this.normalizeAddress(tokenAddress);
      console.log('🔍 Validating ERC20 contract:', normalizedTokenAddress);
      console.log('🌐 Network:', this.network.name, 'Chain ID:', this.network.chainId);
      
      // Use network-specific provider to avoid network change errors
      const networkProvider = this.createNetworkSpecificProvider();
      
      // Step 1: Check if address has code (is a contract)
      console.log('📋 Step 1: Checking if address has contract code...');
      const code = await networkProvider.getCode(normalizedTokenAddress);
      console.log('📋 Contract code length:', code.length);
      
      if (code === '0x') {
        console.log('❌ Address has no code, not a contract');
        return false;
      }
      console.log('✅ Address has contract code');
      
      // Step 2: Try to create contract instance with network-specific provider
      console.log('📋 Step 2: Creating contract instance...');
      const tokenContract = new Contract(normalizedTokenAddress, ERC20_ABI, networkProvider);
      
      // Step 3: Test multiple ERC20 functions with detailed logging
      console.log('📋 Step 3: Testing ERC20 functions...');
      
      const testResults = {
        decimals: false,
        symbol: false,
        name: false,
        totalSupply: false,
        balanceOf: false
      };
      
      // Test decimals()
      try {
        console.log('🧪 Testing decimals()...');
        const decimals = await tokenContract.decimals();
        console.log('✅ decimals() success:', decimals.toString());
        testResults.decimals = true;
      } catch (error) {
        console.log('❌ decimals() failed:', error.message);
      }
      
      // Test symbol()
      try {
        console.log('🧪 Testing symbol()...');
        const symbol = await tokenContract.symbol();
        console.log('✅ symbol() success:', symbol);
        testResults.symbol = true;
      } catch (error) {
        console.log('❌ symbol() failed:', error.message);
      }
      
      // Test name()
      try {
        console.log('🧪 Testing name()...');
        const name = await tokenContract.name();
        console.log('✅ name() success:', name);
        testResults.name = true;
      } catch (error) {
        console.log('❌ name() failed:', error.message);
      }
      
      // Test totalSupply()
      try {
        console.log('🧪 Testing totalSupply()...');
        const totalSupply = await tokenContract.totalSupply();
        console.log('✅ totalSupply() success:', totalSupply.toString());
        testResults.totalSupply = true;
      } catch (error) {
        console.log('❌ totalSupply() failed:', error.message);
      }
      
      // Test balanceOf() with zero address
      try {
        console.log('🧪 Testing balanceOf()...');
        const balance = await tokenContract.balanceOf('0x0000000000000000000000000000000000000000');
        console.log('✅ balanceOf() success:', balance.toString());
        testResults.balanceOf = true;
      } catch (error) {
        console.log('❌ balanceOf() failed:', error.message);
      }
      
      // Count successful tests
      const successCount = Object.values(testResults).filter(Boolean).length;
      console.log('📊 Test results:', testResults);
      console.log('📊 Successful tests:', successCount, '/ 5');
      
      // Consider valid if at least 3 out of 5 core functions work
      // This is more lenient for tokens that might not implement all optional functions
      const isValid = successCount >= 3;
      
      console.log(isValid ? '✅ Token validation PASSED' : '❌ Token validation FAILED');
      
      return isValid;
    } catch (error) {
      console.error('💥 Critical error during token validation:', error);
      return false;
    }
  }

  // Enhanced token info retrieval with comprehensive error handling and custom logos
  async getTokenInfo(tokenAddress: string): Promise<Token | null> {
    try {
      console.log('🔍 Getting token info for:', tokenAddress);
      
      if (tokenAddress === 'ETH') {
        return {
          address: 'ETH',
          name: 'Ethereum',
          symbol: 'ETH',
          logoURI: 'https://token-icons.s3.amazonaws.com/eth.png',
          decimals: 18,
          chainId: this.network.chainId,
          isNative: true
        };
      }

      const normalizedTokenAddress = this.normalizeAddress(tokenAddress);
      
      // First validate if this is a valid ERC20 contract
      console.log('🔍 Validating token contract...');
      const isValid = await this.isValidERC20Contract(normalizedTokenAddress);
      
      if (!isValid) {
        console.log('❌ Token validation failed');
        return null;
      }

      console.log('✅ Token validation passed, retrieving token info...');
      
      // Use network-specific provider to avoid network change errors
      const networkProvider = this.createNetworkSpecificProvider();
      const tokenContract = new Contract(normalizedTokenAddress, ERC20_ABI, networkProvider);
      
      // Get token information with individual error handling and fallbacks
      let decimals = 18;
      let symbol = '';
      let name = '';
      
      // Get decimals with fallback
      try {
        const decimalsResult = await tokenContract.decimals();
        decimals = Number(decimalsResult);
        console.log('✅ Decimals retrieved:', decimals);
      } catch (error) {
        console.log('⚠️ Decimals failed, using default 18:', error.message);
        decimals = 18;
      }
      
      // Get symbol with fallback
      try {
        const symbolResult = await tokenContract.symbol();
        symbol = String(symbolResult).trim();
        console.log('✅ Symbol retrieved:', symbol);
      } catch (error) {
        console.log('❌ Symbol failed:', error.message);
        // Try to extract symbol from address as last resort
        symbol = `TOKEN_${normalizedTokenAddress.slice(2, 8).toUpperCase()}`;
      }
      
      // Get name with fallback
      try {
        const nameResult = await tokenContract.name();
        name = String(nameResult).trim();
        console.log('✅ Name retrieved:', name);
      } catch (error) {
        console.log('⚠️ Name failed, using fallback:', error.message);
        name = symbol ? `${symbol} Token` : 'Unknown Token';
      }
      
      console.log('📊 Final token info:', { decimals, symbol, name });
      
      // Final validation: symbol should not be empty
      if (!symbol || symbol === 'UNKNOWN' || symbol.trim() === '') {
        console.log('❌ Token has invalid or empty symbol');
        return null;
      }

      const tokenInfo = {
        address: tokenAddress, // Keep original address format
        name: name || 'Unknown Token',
        symbol: symbol,
        logoURI: this.generateTokenLogo(symbol), // Use custom logo generator
        decimals: decimals,
        chainId: this.network.chainId,
        isNative: false
      };
      
      console.log('✅ Token info successfully created:', tokenInfo);
      return tokenInfo;
    } catch (error) {
      console.error('💥 Critical error getting token info:', error);
      return null;
    }
  }

  async getTokenBalance(tokenAddress: string, userAddress: string): Promise<string> {
    try {
      if (tokenAddress === 'ETH') {
        const balance = await this.provider.getBalance(userAddress);
        return formatUnits(balance, 18);
      } else {
        const normalizedTokenAddress = this.normalizeAddress(tokenAddress);
        
        // First validate if this is a valid ERC20 contract
        const isValid = await this.isValidERC20Contract(normalizedTokenAddress);
        if (!isValid) {
          console.warn(`Skipping balance check for invalid token address: ${tokenAddress}`);
          return '0';
        }
        
        // Use network-specific provider for balance checks to avoid network errors
        const networkProvider = this.createNetworkSpecificProvider();
        const tokenContract = new Contract(normalizedTokenAddress, ERC20_ABI, networkProvider);
        
        // Get balance and decimals with proper error handling
        const [balance, decimals] = await Promise.all([
          tokenContract.balanceOf(userAddress).catch((error) => {
            console.warn(`Failed to get balance for ${tokenAddress}:`, error.message);
            return BigInt(0);
          }),
          tokenContract.decimals().catch((error) => {
            console.warn(`Failed to get decimals for ${tokenAddress}:`, error.message);
            return 18; // Default to 18 decimals
          })
        ]);
        
        return formatUnits(balance, decimals);
      }
    } catch (error) {
      console.error('Error getting token balance:', error);
      return '0';
    }
  }

  async getPairAddress(tokenA: Token, tokenB: Token): Promise<string> {
    try {
      const factoryContract = this.getFactoryContract();
      const tokenAAddress = tokenA.isNative ? this.network.contracts.WETH.address : this.normalizeAddress(tokenA.address);
      const tokenBAddress = tokenB.isNative ? this.network.contracts.WETH.address : this.normalizeAddress(tokenB.address);
      
      console.log('Getting pair for:', tokenAAddress, 'and', tokenBAddress);
      const pairAddress = await factoryContract.getPair(tokenAAddress, tokenBAddress);
      console.log('Pair address result:', pairAddress);
      
      return pairAddress;
    } catch (error) {
      // Check if this is the specific BAD_DATA error for non-existent pairs
      if (error.code === 'BAD_DATA' && 
          error.value === '0x' && 
          error.info?.method === 'getPair') {
        console.warn('No pair exists for these tokens (factory returned empty data)');
        return '0x0000000000000000000000000000000000000000';
      }
      
      console.error('Error getting pair address:', error);
      return '0x0000000000000000000000000000000000000000';
    }
  }

  async getPairReserves(tokenA: Token, tokenB: Token): Promise<PairReserves | null> {
    try {
      const pairAddress = await this.getPairAddress(tokenA, tokenB);
      
      if (pairAddress === '0x0000000000000000000000000000000000000000') {
        return null; // No pair exists
      }

      const pairContract = this.getPairContract(pairAddress);
      const reserves = await pairContract.getReserves();
      const token0 = await pairContract.token0();
      const token1 = await pairContract.token1();

      const tokenAAddress = tokenA.isNative ? this.network.contracts.WETH.address : this.normalizeAddress(tokenA.address);
      const tokenBAddress = tokenB.isNative ? this.network.contracts.WETH.address : this.normalizeAddress(tokenB.address);

      // Determine which reserve corresponds to which token
      let reserveA, reserveB;
      if (token0.toLowerCase() === tokenAAddress.toLowerCase()) {
        reserveA = formatUnits(reserves._reserve0, tokenA.decimals);
        reserveB = formatUnits(reserves._reserve1, tokenB.decimals);
      } else {
        reserveA = formatUnits(reserves._reserve1, tokenA.decimals);
        reserveB = formatUnits(reserves._reserve0, tokenB.decimals);
      }

      return { reserveA, reserveB };
    } catch (error) {
      console.error('Error getting pair reserves:', error);
      return null;
    }
  }

  async getUserLiquidityPositions(userAddress: string, availableTokens: Token[]): Promise<LiquidityPosition[]> {
    try {
      console.log('=== Starting comprehensive liquidity position detection ===');
      console.log('User address:', userAddress);
      console.log('Network:', this.network.name, 'Chain ID:', this.network.chainId);
      console.log('Available tokens:', availableTokens.map(t => `${t.symbol} (${t.address})`));
      console.log('Factory address:', this.network.contracts.FACTORY.address);
      
      const positions: LiquidityPosition[] = [];
      const factoryContract = this.getFactoryContract();
      
      try {
        // Get total number of pairs from factory
        const allPairsLength = await factoryContract.allPairsLength();
        console.log('Total pairs in factory:', allPairsLength.toString());
        
        // Check all pairs in the factory
        for (let i = 0; i < Number(allPairsLength); i++) {
          try {
            const pairAddress = await factoryContract.allPairs(i);
            console.log(`\n--- Checking pair ${i + 1}/${allPairsLength}: ${pairAddress} ---`);
            
            if (pairAddress === '0x0000000000000000000000000000000000000000') {
              console.log('❌ Invalid pair address, skipping');
              continue;
            }
            
            const pairContract = this.getPairContract(pairAddress);
            
            // Get user's LP token balance for this pair
            const lpBalance = await pairContract.balanceOf(userAddress);
            console.log('LP balance (raw):', lpBalance.toString());
            
            if (lpBalance > 0) {
              console.log('✅ Found LP tokens! Getting pair details...');
              
              // Get token addresses from the pair
              const [token0Address, token1Address, reserves, totalSupply] = await Promise.all([
                pairContract.token0(),
                pairContract.token1(),
                pairContract.getReserves(),
                pairContract.totalSupply()
              ]);
              
              console.log('Token0:', token0Address);
              console.log('Token1:', token1Address);
              console.log('Reserves:', reserves._reserve0.toString(), reserves._reserve1.toString());
              console.log('Total supply:', totalSupply.toString());
              
              // Try to find matching tokens in our available tokens list
              let tokenA: Token | null = null;
              let tokenB: Token | null = null;
              
              // Check if tokens are WETH (native ETH)
              const wethAddress = this.network.contracts.WETH.address.toLowerCase();
              
              for (const token of availableTokens) {
                const tokenAddress = token.isNative ? wethAddress : token.address.toLowerCase();
                
                if (tokenAddress === token0Address.toLowerCase()) {
                  tokenA = token;
                  console.log('Found tokenA:', token.symbol);
                } else if (tokenAddress === token1Address.toLowerCase()) {
                  tokenB = token;
                  console.log('Found tokenB:', token.symbol);
                }
              }
              
              // If we couldn't find tokens in our list, try to get their info from contracts
              if (!tokenA) {
                console.log('TokenA not in list, fetching from contract...');
                if (token0Address.toLowerCase() === wethAddress) {
                  tokenA = availableTokens.find(t => t.isNative) || null;
                } else {
                  tokenA = await this.getTokenInfo(token0Address);
                }
              }
              
              if (!tokenB) {
                console.log('TokenB not in list, fetching from contract...');
                if (token1Address.toLowerCase() === wethAddress) {
                  tokenB = availableTokens.find(t => t.isNative) || null;
                } else {
                  tokenB = await this.getTokenInfo(token1Address);
                }
              }
              
              if (tokenA && tokenB) {
                console.log('✅ Both tokens identified:', tokenA.symbol, tokenB.symbol);
                
                // Calculate user's share
                const share = (Number(formatUnits(lpBalance, 18)) / Number(formatUnits(totalSupply, 18))) * 100;
                console.log('User share:', share, '%');
                
                // Calculate user's underlying token amounts
                const reserve0Formatted = formatUnits(reserves._reserve0, tokenA.decimals);
                const reserve1Formatted = formatUnits(reserves._reserve1, tokenB.decimals);
                
                const userReserveA = (parseFloat(reserve0Formatted) * share / 100).toString();
                const userReserveB = (parseFloat(reserve1Formatted) * share / 100).toString();
                
                console.log('User reserves:', userReserveA, tokenA.symbol, userReserveB, tokenB.symbol);
                
                const position = {
                  tokenA,
                  tokenB,
                  liquidityTokens: formatUnits(lpBalance, 18),
                  share,
                  reserveA: userReserveA,
                  reserveB: userReserveB,
                  pairAddress
                };
                
                positions.push(position);
                console.log('✅ Position added:', position);
              } else {
                console.log('❌ Could not identify both tokens for pair');
                console.log('TokenA:', tokenA ? tokenA.symbol : 'null');
                console.log('TokenB:', tokenB ? tokenB.symbol : 'null');
              }
            } else {
              console.log('❌ No LP tokens found for this pair');
            }
          } catch (error) {
            console.log(`❌ Error checking pair ${i}:`, error.message);
            continue;
          }
        }
      } catch (error) {
        console.error('Error getting pairs from factory:', error);
        
        // Fallback: check specific token pairs from available tokens
        console.log('Falling back to checking specific token pairs...');
        
        for (let i = 0; i < availableTokens.length; i++) {
          for (let j = i + 1; j < availableTokens.length; j++) {
            const tokenA = availableTokens[i];
            const tokenB = availableTokens[j];
            
            console.log(`\n--- Fallback: Checking pair: ${tokenA.symbol}/${tokenB.symbol} ---`);
            
            try {
              const pairAddress = await this.getPairAddress(tokenA, tokenB);
              console.log('Pair address:', pairAddress);
              
              if (pairAddress !== '0x0000000000000000000000000000000000000000') {
                const pairContract = this.getPairContract(pairAddress);
                
                // Get user's LP token balance
                console.log('Checking LP balance for user:', userAddress);
                const lpBalance = await pairContract.balanceOf(userAddress);
                console.log('LP balance (raw):', lpBalance.toString());
                console.log('LP balance (formatted):', formatUnits(lpBalance, 18));
                
                if (lpBalance > 0) {
                  console.log('✅ Found LP tokens! Getting position details...');
                  
                  // Get total supply of LP tokens
                  const totalSupply = await pairContract.totalSupply();
                  console.log('Total supply:', formatUnits(totalSupply, 18));
                  
                  // Get pair reserves
                  const reserves = await this.getPairReserves(tokenA, tokenB);
                  console.log('Reserves:', reserves);
                  
                  if (reserves) {
                    // Calculate user's share
                    const share = (Number(formatUnits(lpBalance, 18)) / Number(formatUnits(totalSupply, 18))) * 100;
                    console.log('User share:', share, '%');
                    
                    // Calculate user's underlying token amounts
                    const userReserveA = (parseFloat(reserves.reserveA) * share / 100).toString();
                    const userReserveB = (parseFloat(reserves.reserveB) * share / 100).toString();
                    console.log('User reserves:', userReserveA, tokenA.symbol, userReserveB, tokenB.symbol);
                    
                    const position = {
                      tokenA,
                      tokenB,
                      liquidityTokens: formatUnits(lpBalance, 18),
                      share,
                      reserveA: userReserveA,
                      reserveB: userReserveB,
                      pairAddress
                    };
                    
                    positions.push(position);
                    console.log('✅ Position added:', position);
                  }
                } else {
                  console.log('❌ No LP tokens found for this pair');
                }
              } else {
                console.log('❌ No pair exists for this token combination');
              }
            } catch (error) {
              console.log(`❌ Error checking pair ${tokenA.symbol}/${tokenB.symbol}:`, error.message);
              continue;
            }
          }
        }
      }
      
      console.log('\n=== Final results ===');
      console.log('Total positions found:', positions.length);
      positions.forEach((pos, index) => {
        console.log(`Position ${index + 1}: ${pos.tokenA.symbol}/${pos.tokenB.symbol} - ${pos.share.toFixed(4)}% share`);
      });
      
      return positions;
    } catch (error) {
      console.error('Error getting liquidity positions:', error);
      return [];
    }
  }

  async getSwapQuote(
    tokenIn: Token,
    tokenOut: Token,
    amountIn: string
  ): Promise<SwapQuote | null> {
    try {
      const routerContract = this.getRouterContract();
      const amountInWei = this.safeParseUnits(amountIn, tokenIn.decimals);

      // Build the path for the swap
      const path = this.buildSwapPath(tokenIn, tokenOut);
      
      const amounts = await routerContract.getAmountsOut(amountInWei, path);
      const amountOut = amounts[amounts.length - 1];
      const amountOutFormatted = formatUnits(amountOut, tokenOut.decimals);

      // Calculate price impact (simplified)
      const priceImpact = this.calculatePriceImpact(amountIn, amountOutFormatted);

      // Calculate minimum amount out with slippage (0.5% default)
      const slippageTolerance = 0.005;
      const minAmountOut = (BigInt(amountOut) * BigInt(Math.floor((1 - slippageTolerance) * 10000))) / BigInt(10000);

      return {
        amountOut: amountOutFormatted,
        path,
        priceImpact,
        minAmountOut: formatUnits(minAmountOut, tokenOut.decimals),
      };
    } catch (error) {
      console.error('Error getting swap quote:', error);
      return null;
    }
  }

  private buildSwapPath(tokenIn: Token, tokenOut: Token): string[] {
    const wethAddress = this.network.contracts.WETH.address;

    if (tokenIn.isNative) {
      return [wethAddress, this.normalizeAddress(tokenOut.address)];
    } else if (tokenOut.isNative) {
      return [this.normalizeAddress(tokenIn.address), wethAddress];
    } else {
      // Token to token swap through WETH
      return [this.normalizeAddress(tokenIn.address), wethAddress, this.normalizeAddress(tokenOut.address)];
    }
  }

  private calculatePriceImpact(amountIn: string, amountOut: string): number {
    // Simplified price impact calculation
    // In a real implementation, you'd need to compare with the ideal exchange rate
    return 0.1; // Placeholder 0.1%
  }

  async executeSwap(
    tokenIn: Token,
    tokenOut: Token,
    amountIn: string,
    minAmountOut: string,
    userAddress: string,
    signer: any
  ): Promise<any> {
    try {
      const routerContract = this.getRouterContract(signer);
      const amountInWei = this.safeParseUnits(amountIn, tokenIn.decimals);
      const minAmountOutWei = this.safeParseUnits(minAmountOut, tokenOut.decimals);
      const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes
      const path = this.buildSwapPath(tokenIn, tokenOut);

      let tx;

      if (tokenIn.isNative) {
        // ETH to Token swap
        tx = await routerContract.swapExactETHForTokens(
          minAmountOutWei,
          path,
          userAddress,
          deadline,
          { value: amountInWei }
        );
      } else if (tokenOut.isNative) {
        // Token to ETH swap
        tx = await routerContract.swapExactTokensForETH(
          amountInWei,
          minAmountOutWei,
          path,
          userAddress,
          deadline
        );
      } else {
        // Token to Token swap
        tx = await routerContract.swapExactTokensForTokens(
          amountInWei,
          minAmountOutWei,
          path,
          userAddress,
          deadline
        );
      }

      return tx;
    } catch (error) {
      console.error('Error executing swap:', error);
      throw error;
    }
  }

  async approveToken(
    tokenAddress: string,
    spenderAddress: string,
    amount: string,
    decimals: number,
    signer: any
  ): Promise<any> {
    try {
      const normalizedTokenAddress = this.normalizeAddress(tokenAddress);
      const tokenContract = this.getTokenContract(normalizedTokenAddress, signer);
      const amountWei = this.safeParseUnits(amount, decimals);
      const tx = await tokenContract.approve(spenderAddress, amountWei);
      return tx;
    } catch (error) {
      console.error('Error approving token:', error);
      throw error;
    }
  }

  async getTokenAllowance(
    tokenAddress: string,
    ownerAddress: string,
    spenderAddress: string,
    decimals: number
  ): Promise<string> {
    try {
      const normalizedTokenAddress = this.normalizeAddress(tokenAddress);
      const tokenContract = this.getTokenContract(normalizedTokenAddress);
      const allowance = await tokenContract.allowance(ownerAddress, spenderAddress);
      return formatUnits(allowance, decimals);
    } catch (error) {
      console.error('Error getting token allowance:', error);
      return '0';
    }
  }

  async addLiquidity(
    tokenA: Token,
    tokenB: Token,
    amountA: string,
    amountB: string,
    minAmountA: string,
    minAmountB: string,
    userAddress: string,
    signer: any
  ): Promise<any> {
    try {
      const routerContract = this.getRouterContract(signer);
      const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes

      // Use safe parsing to avoid scientific notation issues
      const amountAWei = this.safeParseUnits(amountA, tokenA.decimals);
      const amountBWei = this.safeParseUnits(amountB, tokenB.decimals);
      const minAmountAWei = this.safeParseUnits(minAmountA, tokenA.decimals);
      const minAmountBWei = this.safeParseUnits(minAmountB, tokenB.decimals);

      let tx;

      if (tokenA.isNative || tokenB.isNative) {
        const token = tokenA.isNative ? tokenB : tokenA;
        const amountToken = tokenA.isNative ? amountB : amountA;
        const amountETH = tokenA.isNative ? amountA : amountB;
        const minAmountToken = tokenA.isNative ? minAmountB : minAmountA;
        const minAmountETH = tokenA.isNative ? minAmountA : minAmountB;

        tx = await routerContract.addLiquidityETH(
          this.normalizeAddress(token.address),
          this.safeParseUnits(amountToken, token.decimals),
          this.safeParseUnits(minAmountToken, token.decimals),
          this.safeParseUnits(minAmountETH, 18),
          userAddress,
          deadline,
          { value: this.safeParseUnits(amountETH, 18) }
        );
      } else {
        tx = await routerContract.addLiquidity(
          this.normalizeAddress(tokenA.address),
          this.normalizeAddress(tokenB.address),
          amountAWei,
          amountBWei,
          minAmountAWei,
          minAmountBWei,
          userAddress,
          deadline
        );
      }

      return tx;
    } catch (error) {
      console.error('Error adding liquidity:', error);
      throw error;
    }
  }

  async removeLiquidity(
    tokenA: Token,
    tokenB: Token,
    liquidity: string,
    minAmountA: string,
    minAmountB: string,
    userAddress: string,
    signer: any
  ): Promise<any> {
    try {
      const routerContract = this.getRouterContract(signer);
      const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes

      // Use safeParseUnits for all amount conversions to prevent overflow
      const liquidityWei = this.safeParseUnits(liquidity, 18); // LP tokens are always 18 decimals
      const minAmountAWei = this.safeParseUnits(minAmountA, tokenA.decimals);
      const minAmountBWei = this.safeParseUnits(minAmountB, tokenB.decimals);

      console.log('Remove liquidity params:', {
        liquidityWei: liquidityWei.toString(),
        minAmountAWei: minAmountAWei.toString(),
        minAmountBWei: minAmountBWei.toString(),
        tokenA: tokenA.symbol,
        tokenB: tokenB.symbol
      });

      let tx;

      if (tokenA.isNative || tokenB.isNative) {
        const token = tokenA.isNative ? tokenB : tokenA;
        const minAmountToken = tokenA.isNative ? minAmountBWei : minAmountAWei;
        const minAmountETH = tokenA.isNative ? minAmountAWei : minAmountBWei;

        tx = await routerContract.removeLiquidityETH(
          this.normalizeAddress(token.address),
          liquidityWei,
          minAmountToken,
          minAmountETH,
          userAddress,
          deadline
        );
      } else {
        tx = await routerContract.removeLiquidity(
          this.normalizeAddress(tokenA.address),
          this.normalizeAddress(tokenB.address),
          liquidityWei,
          minAmountAWei,
          minAmountBWei,
          userAddress,
          deadline
        );
      }

      return tx;
    } catch (error) {
      console.error('Error removing liquidity:', error);
      throw error;
    }
  }
}