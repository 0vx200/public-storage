import React, { useState, useEffect } from 'react';
import { ArrowDownUp, Settings, ChevronDown, CheckCircle, XCircle, Loader } from 'lucide-react';
import { Token, Network, SwapQuote } from '../types';
import { TokenSelector } from './TokenSelector';
import { ContractService } from '../services/contractService';
import { useWallet } from '../hooks/useWallet';
import { getTokensForChain } from '../config/tokens';

interface SwapInterfaceProps {
  currentNetwork: Network;
}

type TransactionStatus = 'idle' | 'pending' | 'success' | 'error';

interface TransactionState {
  status: TransactionStatus;
  message: string;
  hash?: string;
}

// Stable token logo component
const TokenLogo = ({ token, className = "w-6 h-6 sm:w-8 sm:h-8" }: { token: Token; className?: string }) => {
  const [hasError, setHasError] = useState(false);
  
  const generateStableLogo = (symbol: string) => {
    if (!symbol || symbol.trim() === '') return 'https://via.placeholder.com/32x32/06b6d4/ffffff?text=T';
    const firstChar = symbol.trim().charAt(0).toUpperCase();
    return `https://via.placeholder.com/32x32/06b6d4/ffffff?text=${firstChar}`;
  };

  const logoUrl = hasError || token.logoURI.includes('via.placeholder.com') 
    ? generateStableLogo(token.symbol)
    : token.logoURI;

  return (
    <div className={`${className} rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold flex-shrink-0`}>
      {!hasError && !token.logoURI.includes('via.placeholder.com') ? (
        <img
          src={token.logoURI}
          alt={token.symbol}
          className={`${className} rounded-full object-cover`}
          onError={() => setHasError(true)}
          onLoad={() => setHasError(false)}
        />
      ) : (
        <span className="text-xs font-bold">
          {token.symbol ? token.symbol.charAt(0).toUpperCase() : 'T'}
        </span>
      )}
    </div>
  );
};

export function SwapInterface({ currentNetwork }: SwapInterfaceProps) {
  const { isConnected, address, signer, provider } = useWallet();
  const [tokens, setTokens] = useState<Token[]>([]);
  const [tokenIn, setTokenIn] = useState<Token | null>(null);
  const [tokenOut, setTokenOut] = useState<Token | null>(null);
  const [amountIn, setAmountIn] = useState('');
  const [amountOut, setAmountOut] = useState('');
  const [showTokenInSelector, setShowTokenInSelector] = useState(false);
  const [showTokenOutSelector, setShowTokenOutSelector] = useState(false);
  const [quote, setQuote] = useState<SwapQuote | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [balanceIn, setBalanceIn] = useState('0');
  const [balanceOut, setBalanceOut] = useState('0');
  const [contractService, setContractService] = useState<ContractService | null>(null);
  const [transaction, setTransaction] = useState<TransactionState>({ status: 'idle', message: '' });

  // Initialize tokens and contract service when network changes
  useEffect(() => {
    console.log('SwapInterface: Network changed to', currentNetwork.name);
    const newTokens = getTokensForChain(currentNetwork.chainId);
    setTokens(newTokens);
    setTokenIn(newTokens[0] || null);
    setTokenOut(newTokens[1] || null);
    setAmountIn('');
    setAmountOut('');
    setQuote(null);
    setTransaction({ status: 'idle', message: '' });
    
    // Create new contract service for the current network
    const newContractService = new ContractService(currentNetwork, provider);
    setContractService(newContractService);
  }, [currentNetwork.chainId, provider]);

  useEffect(() => {
    if (isConnected && address && tokenIn && contractService) {
      contractService.getTokenBalance(tokenIn.address, address).then(setBalanceIn);
    } else {
      setBalanceIn('0');
    }
  }, [isConnected, address, tokenIn, contractService]);

  useEffect(() => {
    if (isConnected && address && tokenOut && contractService) {
      contractService.getTokenBalance(tokenOut.address, address).then(setBalanceOut);
    } else {
      setBalanceOut('0');
    }
  }, [isConnected, address, tokenOut, contractService]);

  useEffect(() => {
    const getQuote = async () => {
      if (tokenIn && tokenOut && amountIn && parseFloat(amountIn) > 0 && contractService) {
        setIsLoading(true);
        try {
          const newQuote = await contractService.getSwapQuote(tokenIn, tokenOut, amountIn);
          setQuote(newQuote);
          setAmountOut(newQuote?.amountOut || '');
        } catch (error) {
          console.error('Error getting quote:', error);
          setQuote(null);
          setAmountOut('');
        }
        setIsLoading(false);
      } else {
        setQuote(null);
        setAmountOut('');
      }
    };

    const timeoutId = setTimeout(getQuote, 500);
    return () => clearTimeout(timeoutId);
  }, [tokenIn, tokenOut, amountIn, contractService]);

  const handleSwapTokens = () => {
    const tempToken = tokenIn;
    setTokenIn(tokenOut);
    setTokenOut(tempToken);
    setAmountIn(amountOut);
    setAmountOut(amountIn);
  };

  const handleMaxClick = () => {
    if (tokenIn?.isNative) {
      // Reserve some ETH for gas
      const maxAmount = Math.max(0, parseFloat(balanceIn) - 0.01);
      setAmountIn(maxAmount.toString());
    } else {
      setAmountIn(balanceIn);
    }
  };

  const handleSwap = async () => {
    if (!isConnected || !signer || !tokenIn || !tokenOut || !quote || !address || !contractService) {
      setTransaction({ status: 'error', message: 'Please connect your wallet and ensure all fields are filled' });
      return;
    }

    try {
      setIsLoading(true);
      setTransaction({ status: 'pending', message: 'Preparing swap...' });

      // Check if token approval is needed
      if (!tokenIn.isNative) {
        setTransaction({ status: 'pending', message: 'Checking token approval...' });
        const allowance = await contractService.getTokenAllowance(
          tokenIn.address,
          address,
          currentNetwork.contracts.ROUTER.address,
          tokenIn.decimals
        );

        if (parseFloat(allowance) < parseFloat(amountIn)) {
          setTransaction({ status: 'pending', message: 'Approving token...' });
          const approveTx = await contractService.approveToken(
            tokenIn.address,
            currentNetwork.contracts.ROUTER.address,
            amountIn,
            tokenIn.decimals,
            signer
          );
          setTransaction({ status: 'pending', message: 'Waiting for approval confirmation...', hash: approveTx.hash });
          await approveTx.wait();
        }
      }

      setTransaction({ status: 'pending', message: 'Executing swap...' });
      const tx = await contractService.executeSwap(
        tokenIn,
        tokenOut,
        amountIn,
        quote.minAmountOut,
        address,
        signer
      );

      setTransaction({ status: 'pending', message: 'Waiting for confirmation...', hash: tx.hash });
      await tx.wait();
      
      setTransaction({ status: 'success', message: 'Swap completed successfully!', hash: tx.hash });

      // Refresh balances
      if (address && contractService) {
        contractService.getTokenBalance(tokenIn.address, address).then(setBalanceIn);
        contractService.getTokenBalance(tokenOut.address, address).then(setBalanceOut);
      }

      // Clear form
      setAmountIn('');
      setAmountOut('');
      setQuote(null);

      // Clear success message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } catch (error: any) {
      console.error('Swap failed:', error);
      setTransaction({ status: 'error', message: `Swap failed: ${error.message}` });
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTokenInSelect = (token: Token) => {
    setTokenIn(token);
    // Add to tokens list if it's a custom token
    if (!tokens.find(t => t.address.toLowerCase() === token.address.toLowerCase())) {
      setTokens(prev => [...prev, token]);
    }
  };

  const handleTokenOutSelect = (token: Token) => {
    setTokenOut(token);
    // Add to tokens list if it's a custom token
    if (!tokens.find(t => t.address.toLowerCase() === token.address.toLowerCase())) {
      setTokens(prev => [...prev, token]);
    }
  };

  // Show loading state while initializing
  if (!contractService || tokens.length === 0) {
    return (
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-600/50 p-4 sm:p-6 w-full">
        <div className="flex items-center justify-center py-12">
          <div className="text-slate-400">Loading swap interface...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-600/50 p-4 sm:p-6 w-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-white">Swap</h2>
        <button className="p-2 hover:bg-slate-700/50 rounded-lg transition-colors text-slate-400 hover:text-cyan-300">
          <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>

      {/* Transaction Status */}
      {transaction.status !== 'idle' && (
        <div className={`mb-4 p-3 sm:p-4 rounded-xl border ${
          transaction.status === 'success' 
            ? 'border-green-500/30 bg-green-500/10' 
            : transaction.status === 'error'
            ? 'border-red-500/30 bg-red-500/10'
            : 'border-cyan-500/30 bg-cyan-500/10'
        }`}>
          <div className="flex items-center space-x-3">
            {transaction.status === 'pending' && <Loader className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-cyan-400" />}
            {transaction.status === 'success' && <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />}
            {transaction.status === 'error' && <XCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-400" />}
            <div className="flex-1">
              <p className={`text-xs sm:text-sm font-medium ${
                transaction.status === 'success' 
                  ? 'text-green-300' 
                  : transaction.status === 'error'
                  ? 'text-red-300'
                  : 'text-cyan-300'
              }`}>
                {transaction.message}
              </p>
              {transaction.hash && (
                <a
                  href={`${currentNetwork.explorerUrl}/tx/${transaction.hash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs underline mt-1 block text-cyan-400 hover:text-cyan-300"
                >
                  View transaction
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {/* Token In */}
        <div className="bg-slate-700/30 rounded-xl p-3 sm:p-4 border border-slate-600/30">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs sm:text-sm text-slate-400">From</span>
            {isConnected && (
              <span className="text-xs sm:text-sm text-slate-400">
                Balance: {parseFloat(balanceIn).toFixed(4)} {tokenIn?.symbol}
              </span>
            )}
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 mr-3 sm:mr-4">
              <input
                type="number"
                value={amountIn}
                onChange={(e) => setAmountIn(e.target.value)}
                placeholder="0.0"
                className="w-full bg-transparent text-xl sm:text-2xl font-semibold text-white placeholder-slate-500 focus:outline-none"
              />
              {isConnected && tokenIn && (
                <button
                  onClick={handleMaxClick}
                  className="text-xs sm:text-sm font-medium mt-1 hover:underline text-cyan-400 hover:text-cyan-300"
                >
                  MAX
                </button>
              )}
            </div>
            <button
              onClick={() => setShowTokenInSelector(true)}
              className="flex items-center space-x-2 sm:space-x-3 bg-slate-600/50 hover:bg-slate-600/70 transition-all duration-200 px-3 sm:px-4 py-2 sm:py-3 rounded-xl border border-slate-500/50 shadow-sm hover:shadow-md min-w-[120px] sm:min-w-[140px]"
            >
              {tokenIn ? (
                <>
                  <TokenLogo token={tokenIn} />
                  <div className="flex flex-col items-start">
                    <span className="font-semibold text-white text-xs sm:text-sm">{tokenIn.symbol}</span>
                    <span className="text-xs text-slate-400 truncate max-w-[50px] sm:max-w-[60px] hidden sm:block">{tokenIn.name}</span>
                  </div>
                  <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                </>
              ) : (
                <>
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-slate-600 rounded-full flex-shrink-0"></div>
                  <span className="text-slate-400 font-medium text-xs sm:text-sm">Select</span>
                  <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Swap Button */}
        <div className="flex justify-center py-2">
          <button
            onClick={handleSwapTokens}
            className="p-2 sm:p-3 bg-slate-700/50 hover:bg-slate-600/50 rounded-xl transition-colors shadow-sm hover:shadow-md border border-slate-600/50"
          >
            <ArrowDownUp className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-300" />
          </button>
        </div>

        {/* Token Out */}
        <div className="bg-slate-700/30 rounded-xl p-3 sm:p-4 border border-slate-600/30">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs sm:text-sm text-slate-400">To</span>
            {isConnected && (
              <span className="text-xs sm:text-sm text-slate-400">
                Balance: {parseFloat(balanceOut).toFixed(4)} {tokenOut?.symbol}
              </span>
            )}
          </div>
          <div className="flex items-center justify-between">
            <div className="flex-1 mr-3 sm:mr-4">
              <input
                type="number"
                value={amountOut}
                readOnly
                placeholder="0.0"
                className="w-full bg-transparent text-xl sm:text-2xl font-semibold text-white placeholder-slate-500 focus:outline-none"
              />
            </div>
            <button
              onClick={() => setShowTokenOutSelector(true)}
              className="flex items-center space-x-2 sm:space-x-3 bg-slate-600/50 hover:bg-slate-600/70 transition-all duration-200 px-3 sm:px-4 py-2 sm:py-3 rounded-xl border border-slate-500/50 shadow-sm hover:shadow-md min-w-[120px] sm:min-w-[140px]"
            >
              {tokenOut ? (
                <>
                  <TokenLogo token={tokenOut} />
                  <div className="flex flex-col items-start">
                    <span className="font-semibold text-white text-xs sm:text-sm">{tokenOut.symbol}</span>
                    <span className="text-xs text-slate-400 truncate max-w-[50px] sm:max-w-[60px] hidden sm:block">{tokenOut.name}</span>
                  </div>
                  <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                </>
              ) : (
                <>
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-slate-600 rounded-full flex-shrink-0"></div>
                  <span className="text-slate-400 font-medium text-xs sm:text-sm">Select</span>
                  <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Quote Information */}
      {quote && (
        <div className="mt-4 p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
          <div className="text-xs sm:text-sm space-y-1 text-cyan-300">
            <div className="flex justify-between">
              <span>Price Impact:</span>
              <span className={quote.priceImpact > 2 ? 'text-red-400' : 'text-green-400'}>
                {quote.priceImpact.toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span>Minimum Received:</span>
              <span>{parseFloat(quote.minAmountOut).toFixed(6)} {tokenOut?.symbol}</span>
            </div>
          </div>
        </div>
      )}

      {/* Swap Button */}
      <button
        onClick={handleSwap}
        disabled={!isConnected || !tokenIn || !tokenOut || !amountIn || isLoading || !quote || transaction.status === 'pending'}
        className="w-full mt-6 font-semibold py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed disabled:opacity-50 shadow-lg text-sm sm:text-base"
        style={{ 
          background: (!isConnected || !tokenIn || !tokenOut || !amountIn || isLoading || !quote || transaction.status === 'pending') 
            ? 'linear-gradient(135deg, #64748b, #475569)' 
            : 'linear-gradient(135deg, #06b6d4, #3b82f6)',
          color: 'white'
        }}
      >
        {!isConnected
          ? 'Connect Wallet'
          : transaction.status === 'pending'
          ? 'Processing...'
          : isLoading
          ? 'Loading...'
          : !tokenIn || !tokenOut
          ? 'Select Tokens'
          : !amountIn
          ? 'Enter Amount'
          : 'Swap'}
      </button>

      {/* Token Selectors */}
      <TokenSelector
        tokens={tokens}
        selectedToken={tokenIn}
        onTokenSelect={handleTokenInSelect}
        isOpen={showTokenInSelector}
        onClose={() => setShowTokenInSelector(false)}
        title="Select Input Token"
        currentNetwork={currentNetwork}
      />

      <TokenSelector
        tokens={tokens}
        selectedToken={tokenOut}
        onTokenSelect={handleTokenOutSelect}
        isOpen={showTokenOutSelector}
        onClose={() => setShowTokenOutSelector(false)}
        title="Select Output Token"
        currentNetwork={currentNetwork}
      />
    </div>
  );
}