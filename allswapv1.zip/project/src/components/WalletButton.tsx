import React from 'react';
import { Wallet, LogOut } from 'lucide-react';
import { useWallet } from '../hooks/useWallet';

export function WalletButton() {
  const { isConnected, address, connectWallet, disconnectWallet } = useWallet();

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 4)}...${addr.slice(-4)}`;
  };

  if (isConnected && address) {
    return (
      <div className="flex items-center space-x-1 sm:space-x-2">
        <div className="bg-slate-800/50 border border-slate-600/50 px-2 sm:px-4 py-2 rounded-xl backdrop-blur-sm">
          <div className="flex items-center space-x-1 sm:space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="font-medium text-cyan-300 text-xs sm:text-sm">{formatAddress(address)}</span>
          </div>
        </div>
        <button
          onClick={disconnectWallet}
          className="bg-slate-800/50 hover:bg-red-500/20 transition-colors p-2 rounded-xl border border-slate-600/50 backdrop-blur-sm text-cyan-300 hover:text-red-400"
        >
          <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={connectWallet}
      className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 transition-all px-3 sm:px-6 py-2 rounded-xl font-semibold flex items-center space-x-1 sm:space-x-2 text-white shadow-lg hover:shadow-cyan-500/25 transform hover:scale-105 text-xs sm:text-sm"
    >
      <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />
      <span className="hidden sm:inline">Connect Wallet</span>
      <span className="sm:hidden">Connect</span>
    </button>
  );
}