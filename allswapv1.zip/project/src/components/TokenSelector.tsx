import React, { useState } from 'react';
import { Search, X, Plus, Loader, AlertCircle, CheckCircle } from 'lucide-react';
import { Token } from '../types';
import { ContractService } from '../services/contractService';
import { useWallet } from '../hooks/useWallet';

interface TokenSelectorProps {
  tokens: Token[];
  selectedToken: Token | null;
  onTokenSelect: (token: Token) => void;
  isOpen: boolean;
  onClose: () => void;
  title: string;
  currentNetwork?: any;
}

// Stable logo component that prevents flickering
const TokenLogo = ({ token, className = "w-10 h-10" }: { token: Token; className?: string }) => {
  const [hasError, setHasError] = useState(false);
  
  // Generate stable logo URL based on token symbol
  const generateStableLogo = (symbol: string) => {
    if (!symbol || symbol.trim() === '') return 'https://via.placeholder.com/40x40/06b6d4/ffffff?text=T';
    const firstChar = symbol.trim().charAt(0).toUpperCase();
    return `https://via.placeholder.com/40x40/06b6d4/ffffff?text=${firstChar}`;
  };

  // Use stable logo if original fails or if it's already a placeholder
  const logoUrl = hasError || token.logoURI.includes('via.placeholder.com') 
    ? generateStableLogo(token.symbol)
    : token.logoURI;

  return (
    <div className={`${className} rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold flex-shrink-0`}>
      {!hasError && !token.logoURI.includes('via.placeholder.com') ? (
        <img
          src={token.logoURI}
          alt={token.symbol}
          className={`${className} rounded-full object-cover`}
          onError={() => setHasError(true)}
          onLoad={() => setHasError(false)}
        />
      ) : (
        <span className="text-sm font-bold">
          {token.symbol ? token.symbol.charAt(0).toUpperCase() : 'T'}
        </span>
      )}
    </div>
  );
};

export function TokenSelector({
  tokens,
  selectedToken,
  onTokenSelect,
  isOpen,
  onClose,
  title,
  currentNetwork,
}: TokenSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [customTokenAddress, setCustomTokenAddress] = useState('');
  const [isLoadingCustomToken, setIsLoadingCustomToken] = useState(false);
  const [customTokenError, setCustomTokenError] = useState('');
  const [customTokenSuccess, setCustomTokenSuccess] = useState('');
  const [showCustomTokenInput, setShowCustomTokenInput] = useState(false);
  const { provider } = useWallet();

  const filteredTokens = tokens.filter(
    (token) =>
      token.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddCustomToken = async () => {
    if (!customTokenAddress.trim() || !currentNetwork || !provider) {
      setCustomTokenError('Please enter a valid token address');
      return;
    }

    // Basic address validation
    if (!/^0x[a-fA-F0-9]{40}$/.test(customTokenAddress.trim())) {
      setCustomTokenError('Invalid address format. Address must be 42 characters starting with 0x');
      return;
    }

    setIsLoadingCustomToken(true);
    setCustomTokenError('');
    setCustomTokenSuccess('');

    try {
      console.log('Adding custom token:', customTokenAddress.trim());
      const contractService = new ContractService(currentNetwork, provider);
      
      // First check if it's a valid ERC20 contract
      const isValid = await contractService.isValidERC20Contract(customTokenAddress.trim());
      
      if (!isValid) {
        setCustomTokenError('Invalid token contract or not an ERC20 token. Please check the address.');
        return;
      }
      
      const tokenInfo = await contractService.getTokenInfo(customTokenAddress.trim());

      if (tokenInfo) {
        // Check if token already exists in the list
        const existingToken = tokens.find(
          t => t.address.toLowerCase() === tokenInfo.address.toLowerCase()
        );

        if (existingToken) {
          setCustomTokenError('Token already exists in the list');
          return;
        }

        setCustomTokenSuccess(`Token ${tokenInfo.symbol} (${tokenInfo.name}) added successfully!`);
        onTokenSelect(tokenInfo);
        
        // Clear form and close after a short delay
        setTimeout(() => {
          setCustomTokenAddress('');
          setShowCustomTokenInput(false);
          setCustomTokenSuccess('');
          onClose();
        }, 1500);
      } else {
        setCustomTokenError('Failed to load token information. Please verify the contract address.');
      }
    } catch (error) {
      console.error('Error adding custom token:', error);
      setCustomTokenError('Failed to load token information. Please check the address and try again.');
    } finally {
      setIsLoadingCustomToken(false);
    }
  };

  const handlePasteAddress = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text && /^0x[a-fA-F0-9]{40}$/.test(text.trim())) {
        setCustomTokenAddress(text.trim());
        setCustomTokenError('');
        setCustomTokenSuccess('');
      } else {
        setCustomTokenError('Clipboard does not contain a valid token address');
      }
    } catch (error) {
      console.error('Failed to paste from clipboard:', error);
      setCustomTokenError('Failed to paste from clipboard. Please enter the address manually.');
    }
  };

  const resetCustomTokenForm = () => {
    setShowCustomTokenInput(false);
    setCustomTokenAddress('');
    setCustomTokenError('');
    setCustomTokenSuccess('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800/95 backdrop-blur-sm rounded-2xl w-full max-w-md max-h-[80vh] overflow-hidden border border-slate-600/50 shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b border-slate-600/50">
          <h2 className="text-xl font-semibold text-white">{title}</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-1 hover:bg-slate-700/50 rounded-lg"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-4 border-b border-slate-600/50 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search tokens or paste address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-slate-600/50 rounded-xl focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 bg-slate-700/50 text-white placeholder-slate-400"
            />
          </div>

          {/* Custom Token Input */}
          {showCustomTokenInput ? (
            <div className="space-y-3 p-3 bg-slate-700/30 rounded-lg border border-slate-600/30">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-cyan-300">Add Custom Token</span>
                <button
                  onClick={resetCustomTokenForm}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="0x... Token contract address"
                  value={customTokenAddress}
                  onChange={(e) => {
                    setCustomTokenAddress(e.target.value);
                    setCustomTokenError('');
                    setCustomTokenSuccess('');
                  }}
                  className="flex-1 px-3 py-2 border border-slate-600/50 rounded-lg focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 bg-slate-700/50 text-white placeholder-slate-400 text-sm"
                />
                <button
                  onClick={handlePasteAddress}
                  className="px-3 py-2 bg-slate-600/50 hover:bg-slate-600/70 text-slate-300 rounded-lg text-xs transition-colors"
                >
                  Paste
                </button>
              </div>
              
              {/* Status Messages */}
              {customTokenError && (
                <div className="flex items-center gap-2 text-red-400 text-xs">
                  <AlertCircle className="w-4 h-4" />
                  <span>{customTokenError}</span>
                </div>
              )}
              
              {customTokenSuccess && (
                <div className="flex items-center gap-2 text-green-400 text-xs">
                  <CheckCircle className="w-4 h-4" />
                  <span>{customTokenSuccess}</span>
                </div>
              )}
              
              <button
                onClick={handleAddCustomToken}
                disabled={isLoadingCustomToken || !customTokenAddress.trim()}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 disabled:from-slate-600 disabled:to-slate-700 text-white rounded-lg text-sm font-medium transition-colors disabled:cursor-not-allowed"
              >
                {isLoadingCustomToken ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Validating Token...
                  </>
                ) : (
                  'Add Token'
                )}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowCustomTokenInput(true)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-slate-700/50 hover:bg-slate-700/70 text-cyan-400 rounded-lg text-sm font-medium transition-colors border border-slate-600/50 hover:border-cyan-500/50"
            >
              <Plus className="w-4 h-4" />
              Add Custom Token
            </button>
          )}
        </div>

        <div className="overflow-y-auto max-h-96">
          {filteredTokens.length === 0 && !showCustomTokenInput ? (
            <div className="p-6 text-center text-slate-400">
              <p className="mb-2">No tokens found</p>
              <button
                onClick={() => setShowCustomTokenInput(true)}
                className="text-cyan-400 hover:text-cyan-300 text-sm underline"
              >
                Add custom token instead
              </button>
            </div>
          ) : (
            <div className="p-2">
              {filteredTokens.map((token) => (
                <button
                  key={`${token.address}-${token.chainId}`}
                  onClick={() => {
                    onTokenSelect(token);
                    onClose();
                  }}
                  className={`w-full flex items-center space-x-4 p-4 rounded-xl hover:bg-slate-700/50 transition-colors ${
                    selectedToken?.address === token.address ? 'bg-cyan-500/20 border border-cyan-500/50' : ''
                  }`}
                >
                  <TokenLogo token={token} />
                  <div className="flex-1 text-left">
                    <div className="font-medium text-white">{token.symbol}</div>
                    <div className="text-sm text-slate-400 truncate">{token.name}</div>
                    {token.address !== 'ETH' && (
                      <div className="text-xs text-slate-500 font-mono truncate">
                        {token.address}
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}