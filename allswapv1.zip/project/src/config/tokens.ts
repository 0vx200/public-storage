import { Token } from '../types';

const tokenList = {
  "name": "Multi-Chain Token List",
  "keywords": ["defi", "tokens", "multi-chain"],
  "timestamp": "2024-03-20T00:00:00.000+00:00",
  "tokens": [
    {
      "address": "0x7A2cF13650aaD3c56565FD3F653140F1BC27A08c",
      "name": "OpStack Token",
      "symbol": "OpStack",
      "logoURI": "https://raw.githubusercontent.com/furidngrt/DexSwap/refs/heads/master/MegaETH/opstack.png",
      "decimals": 18,
      "chainId": 1868
    },
    {
      "chainId": 8333,
      "address": "0x64333cD740a7f6624632c58A6C1129DF977CE007",
      "name": "Curl Token",
      "symbol": "CURL",
      "logoURI": "https://i.postimg.cc/nhVSLzPX/curl-token-logo.png",
      "decimals": 18
    },
    {
      "chainId": 130,
      "address": "0xa3CCf8593Ef4CDa3f2d927bAd0d2D90E1f8820c4",
      "name": "Curl Token",
      "symbol": "CURL",
      "logoURI": "https://raw.githubusercontent.com/lineavv/picsme/main/uploader/culr_jz6sfl.png",
      "decimals": 18
    },
    {
      "chainId": 57073,
      "address": "0x0200C29006150606B650577BBE7B6248F58470c1",
      "name": "USD₮0",
      "symbol": "USD₮0",
      "logoURI": "https://inkonchain.com/icons/USDT0.svg",
      "decimals": 18
    },
    {
      "chainId": 2741,
      "address": "0x520d7dAB4A5bCE6ceA323470dbffCea14b78253a",
      "name": "Curl Token",
      "symbol": "CURL",
      "logoURI": "https://raw.githubusercontent.com/lineavv/picsme/main/uploader/culr_jz6sfl.png",
      "decimals": 18
    }
  ],
  "version": {
    "major": 1,
    "minor": 0,
    "patch": 7
  }
};

export function getTokensForChain(chainId: number): Token[] {
  const chainTokens = tokenList.tokens.filter(token => token.chainId === chainId);
  
  // Add native ETH token (not WETH) with stable logo
  const ethToken: Token = {
    address: 'ETH',
    name: 'Ethereum',
    symbol: 'ETH',
    logoURI: 'https://token-icons.s3.amazonaws.com/eth.png',
    decimals: 18,
    chainId: chainId,
    isNative: true
  };

  return [ethToken, ...chainTokens];
}

export function getTokenByAddress(address: string, chainId: number): Token | undefined {
  if (address === 'ETH') {
    return {
      address: 'ETH',
      name: 'Ethereum',
      symbol: 'ETH',
      logoURI: 'https://token-icons.s3.amazonaws.com/eth.png',
      decimals: 18,
      chainId: chainId,
      isNative: true
    };
  }
  
  return tokenList.tokens.find(token => 
    token.address.toLowerCase() === address.toLowerCase() && token.chainId === chainId
  );
}