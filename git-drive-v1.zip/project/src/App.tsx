import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { FileItem } from './components/FileItem';
import { UploadModal } from './components/UploadModal';
import { FilePreview } from './components/FilePreview';
import { CreateFolderModal } from './components/CreateFolderModal';
import { NotificationContainer } from './components/Notification';
import { GitHubService } from './services/github';
import { generateBreadcrumbs, fileToBase64 } from './utils/fileUtils';
import { FileUpload } from './types';
import { RefreshCw, Search } from 'lucide-react';

interface Notification {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message: string;
}

const MainApp: React.FC = () => {
  const { currentUser } = useAuth();
  const [files, setFiles] = useState<any[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [previewFile, setPreviewFile] = useState<any>(null);
  const [uploads, setUploads] = useState<FileUpload[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Auto-collapse sidebar on mobile
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setSidebarCollapsed(true);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadFiles();
    }
  }, [currentPath, currentUser]);

  const addNotification = (type: 'success' | 'error' | 'info', title: string, message: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { id, type, title, message }]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const loadFiles = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await GitHubService.getFiles(currentPath);
      setFiles(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error loading files:', error);
      setError('Failed to load files. Please check your connection.');
      setFiles([]);
      addNotification('error', 'Load Failed', 'Unable to load files from repository');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNavigate = (path: string) => {
    setCurrentPath(path);
    // Auto-collapse sidebar on mobile after navigation
    if (window.innerWidth < 1024) {
      setSidebarCollapsed(true);
    }
  };

  const handleUpload = async (selectedFiles: File[]) => {
    const newUploads: FileUpload[] = selectedFiles.map(file => ({
      file,
      progress: 0,
      status: 'uploading' as const,
      id: Math.random().toString(36).substr(2, 9)
    }));

    setUploads(newUploads);
    let successCount = 0;
    let errorCount = 0;

    for (const upload of newUploads) {
      try {
        const base64Content = await fileToBase64(upload.file);
        const filePath = currentPath ? `${currentPath}/${upload.file.name}` : upload.file.name;
        
        // Simulate progress
        const progressInterval = setInterval(() => {
          setUploads(prev => prev.map(u => 
            u.id === upload.id 
              ? { ...u, progress: Math.min(u.progress + 10, 90) }
              : u
          ));
        }, 100);

        await GitHubService.uploadFile(filePath, base64Content, `Upload ${upload.file.name}`);
        
        clearInterval(progressInterval);
        setUploads(prev => prev.map(u => 
          u.id === upload.id 
            ? { ...u, progress: 100, status: 'completed' as const }
            : u
        ));
        
        successCount++;
      } catch (error) {
        console.error('Upload error:', error);
        setUploads(prev => prev.map(u => 
          u.id === upload.id 
            ? { ...u, status: 'error' as const }
            : u
        ));
        errorCount++;
      }
    }

    // Show notifications based on results
    if (successCount > 0) {
      addNotification(
        'success', 
        'Upload Successful', 
        `${successCount} file${successCount > 1 ? 's' : ''} uploaded successfully`
      );
    }
    
    if (errorCount > 0) {
      addNotification(
        'error', 
        'Upload Failed', 
        `${errorCount} file${errorCount > 1 ? 's' : ''} failed to upload`
      );
    }

    // Refresh files after upload
    setTimeout(() => {
      loadFiles();
      setUploads([]);
    }, 2000);
  };

  const handleDeleteFile = async (file: any) => {
    try {
      if (file.type === 'dir') {
        // Delete folder and all its contents
        await GitHubService.deleteFolder(file.path);
        addNotification('success', 'Folder Deleted', `Folder "${file.name}" and all its contents have been deleted successfully`);
      } else {
        // Delete single file
        await GitHubService.deleteFile(file.path, file.sha, `Delete ${file.name}`);
        addNotification('success', 'File Deleted', `"${file.name}" has been deleted successfully`);
      }
      
      // Refresh the file list
      loadFiles();
    } catch (error) {
      console.error('Delete error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      addNotification(
        'error', 
        'Delete Failed', 
        `Failed to delete "${file.name}": ${errorMessage}`
      );
    }
  };

  const handlePreview = (file: any) => {
    setPreviewFile(file);
    setShowPreview(true);
  };

  const handleCreateFolder = async (folderName: string) => {
    try {
      const folderPath = currentPath ? `${currentPath}/${folderName}` : folderName;
      await GitHubService.createFolder(folderPath);
      loadFiles();
      addNotification('success', 'Folder Created', `Folder "${folderName}" created successfully`);
    } catch (error) {
      console.error('Create folder error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      addNotification('error', 'Create Failed', `Failed to create folder "${folderName}": ${errorMessage}`);
      throw error;
    }
  };

  const filteredFiles = files.filter(file =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const breadcrumbs = generateBreadcrumbs(currentPath);

  if (!currentUser) {
    return <LoginPage />;
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Mobile Overlay */}
      {!sidebarCollapsed && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarCollapsed(true)}
        />
      )}

      {/* Sidebar */}
      <div className={`${sidebarCollapsed ? '-translate-x-full lg:translate-x-0' : 'translate-x-0'} 
        fixed lg:relative z-40 transition-transform duration-300 ease-in-out h-full`}>
        <Sidebar
          currentPath={currentPath}
          viewMode={viewMode}
          onNavigate={handleNavigate}
          onViewModeChange={setViewMode}
          onUploadClick={() => setShowUploadModal(true)}
          onCreateFolder={() => setShowCreateFolderModal(true)}
          isCollapsed={false}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-full">
        {/* Header */}
        <Header
          breadcrumbs={breadcrumbs}
          searchQuery={searchQuery}
          isLoading={isLoading}
          sidebarCollapsed={sidebarCollapsed}
          onNavigate={handleNavigate}
          onSearchChange={setSearchQuery}
          onRefresh={loadFiles}
          onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Content */}
        <div className="flex-1 overflow-auto p-4 sm:p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 animate-in slide-in-from-top duration-300 text-sm">
              {error}
            </div>
          )}

          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto mb-4" />
                <p className="text-gray-600 font-medium">Loading files...</p>
                <p className="text-sm text-gray-500 mt-1">Please wait while we fetch your files</p>
              </div>
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center px-4">
                <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-lg font-medium text-gray-900 mb-2">
                  {searchQuery ? 'No files match your search' : 'This folder is empty'}
                </p>
                <p className="text-gray-500 mb-4 text-sm sm:text-base">
                  {searchQuery ? 'Try adjusting your search terms' : 'Start by uploading your first file'}
                </p>
                {!searchQuery && (
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl text-sm sm:text-base"
                  >
                    Upload Files
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className={
              viewMode === 'grid' 
                ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-3 sm:gap-4 lg:gap-6'
                : 'space-y-2'
            }>
              {filteredFiles.map((file) => (
                <FileItem
                  key={file.path}
                  file={file}
                  viewMode={viewMode}
                  onNavigate={handleNavigate}
                  onDelete={handleDeleteFile}
                  onPreview={handlePreview}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <UploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onUpload={handleUpload}
        uploads={uploads}
      />

      <CreateFolderModal
        isOpen={showCreateFolderModal}
        onClose={() => setShowCreateFolderModal(false)}
        onCreateFolder={handleCreateFolder}
        currentPath={currentPath}
      />

      <FilePreview
        file={previewFile}
        isOpen={showPreview}
        onClose={() => setShowPreview(false)}
      />

      {/* Notifications */}
      <NotificationContainer
        notifications={notifications}
        onClose={removeNotification}
      />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

export default App;