import React, { useState, useEffect } from 'react';
import { 
  X, 
  User, 
  Mail, 
  Save, 
  Camera, 
  Shield, 
  Bell, 
  Palette,
  HardDrive,
  Key,
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  Upload,
  Github,
  TestTube,
  RotateCcw,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { updateProfile, updateEmail, updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { GitHubService, GitHubConfig } from '../services/github';
import { fileToBase64 } from '../utils/fileUtils';

interface SettingsPageProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ isOpen, onClose }) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Profile settings
  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [profilePhotoUrl, setProfilePhotoUrl] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // Password settings
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // GitHub settings
  const [githubConfig, setGithubConfig] = useState<GitHubConfig>({
    owner: '',
    repo: '',
    token: ''
  });
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<{ success: boolean; message: string; repoInfo?: any } | null>(null);
  const [showToken, setShowToken] = useState(false);

  // Preferences
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(false);
  const [theme, setTheme] = useState('light');
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    if (currentUser) {
      setDisplayName(currentUser.displayName || '');
      setEmail(currentUser.email || '');
      loadProfilePhoto();
    }
    loadGitHubConfig();
  }, [currentUser]);

  const loadGitHubConfig = () => {
    const config = GitHubService.getCurrentConfig();
    setGithubConfig(config);
  };

  const loadProfilePhoto = async () => {
    if (!currentUser) return;
    
    try {
      const photoUrl = await GitHubService.getProfilePhoto(currentUser.uid);
      setProfilePhotoUrl(photoUrl);
    } catch (error) {
      // Silently handle errors - profile photo is optional
      console.warn('Could not load profile photo:', error);
      setProfilePhotoUrl(null);
    }
  };

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 5000);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      showMessage('error', 'Please select a valid image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      showMessage('error', 'Image size must be less than 5MB');
      return;
    }

    // Check if GitHub configuration is valid before uploading
    setUploadingPhoto(true);
    try {
      const connectionTest = await GitHubService.testConnection();
      if (!connectionTest.success) {
        showMessage('error', 'GitHub configuration is invalid. Please configure GitHub settings first.');
        return;
      }

      // Convert file to base64
      const base64Content = await fileToBase64(file);
      
      // Generate unique filename
      const timestamp = Date.now();
      const extension = file.name.split('.').pop();
      const fileName = `profile-${timestamp}.${extension}`;

      // Upload to GitHub
      await GitHubService.uploadProfilePhoto(currentUser.uid, base64Content, fileName);
      
      // Update Firebase profile
      const config = GitHubService.getCurrentConfig();
      const newPhotoUrl = `https://raw.githubusercontent.com/${config.owner}/${config.repo}/main/profile/${currentUser.uid}/${fileName}`;
      await updateProfile(currentUser, { photoURL: newPhotoUrl });
      
      setProfilePhotoUrl(newPhotoUrl);
      showMessage('success', 'Profile photo updated successfully!');
    } catch (error: any) {
      console.error('Photo upload error:', error);
      if (error.message?.includes('GitHub API error: 404')) {
        showMessage('error', 'GitHub repository not found. Please check your GitHub configuration.');
      } else if (error.message?.includes('GitHub API error: 401')) {
        showMessage('error', 'Invalid GitHub access token. Please update your GitHub configuration.');
      } else {
        showMessage('error', error.message || 'Failed to upload profile photo');
      }
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    try {
      // Update display name
      if (displayName !== currentUser.displayName) {
        await updateProfile(currentUser, { displayName });
      }

      // Update email if changed
      if (email !== currentUser.email && email) {
        await updateEmail(currentUser, email);
      }

      showMessage('success', 'Profile updated successfully!');
    } catch (error: any) {
      console.error('Profile update error:', error);
      showMessage('error', error.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !currentUser.email) return;

    if (newPassword !== confirmPassword) {
      showMessage('error', 'New passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      showMessage('error', 'Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      // Re-authenticate user before password change
      const credential = EmailAuthProvider.credential(currentUser.email, currentPassword);
      await reauthenticateWithCredential(currentUser, credential);

      // Update password
      await updatePassword(currentUser, newPassword);

      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      showMessage('success', 'Password updated successfully!');
    } catch (error: any) {
      console.error('Password update error:', error);
      if (error.code === 'auth/wrong-password') {
        showMessage('error', 'Current password is incorrect');
      } else {
        showMessage('error', error.message || 'Failed to update password');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setConnectionStatus(null);
    
    try {
      const result = await GitHubService.testConnection();
      setConnectionStatus(result);
    } catch (error) {
      setConnectionStatus({ success: false, message: 'Connection test failed' });
    } finally {
      setTestingConnection(false);
    }
  };

  const handleSaveGitHubConfig = () => {
    if (!githubConfig.owner || !githubConfig.repo || !githubConfig.token) {
      showMessage('error', 'Please fill in all GitHub configuration fields');
      return;
    }

    GitHubService.saveConfig(githubConfig);
    setConnectionStatus(null);
    showMessage('success', 'GitHub configuration saved successfully!');
  };

  const handleResetToDefault = () => {
    if (window.confirm('Are you sure you want to reset to default GitHub configuration?')) {
      GitHubService.resetToDefault();
      loadGitHubConfig();
      setConnectionStatus(null);
      showMessage('success', 'Configuration reset to default');
    }
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'github', label: 'GitHub', icon: Github },
    { id: 'preferences', label: 'Preferences', icon: Palette },
    { id: 'storage', label: 'Storage', icon: HardDrive }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Settings</h2>
            <p className="text-sm text-gray-500 mt-1">Manage your account and preferences</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex h-[calc(90vh-120px)]">
          {/* Sidebar */}
          <div className="w-64 border-r border-gray-100 p-4 overflow-y-auto">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-700 shadow-sm'
                      : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {/* Message */}
            {message && (
              <div className={`mx-6 mt-6 p-4 rounded-xl flex items-center space-x-3 ${
                message.type === 'success' 
                  ? 'bg-green-50 border border-green-200' 
                  : 'bg-red-50 border border-red-200'
              }`}>
                {message.type === 'success' ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-500" />
                )}
                <p className={`text-sm font-medium ${
                  message.type === 'success' ? 'text-green-700' : 'text-red-700'
                }`}>
                  {message.text}
                </p>
              </div>
            )}

            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="p-6">
                <div className="max-w-2xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">Profile Information</h3>
                  
                  {/* Profile Picture */}
                  <div className="flex items-center space-x-6 mb-8">
                    <div className="relative">
                      <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center overflow-hidden">
                        {profilePhotoUrl ? (
                          <img 
                            src={profilePhotoUrl} 
                            alt="Profile" 
                            className="w-20 h-20 rounded-full object-cover"
                          />
                        ) : (
                          <User className="w-10 h-10 text-blue-600" />
                        )}
                      </div>
                      <label className="absolute bottom-0 right-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer">
                        {uploadingPhoto ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <Camera className="w-4 h-4" />
                        )}
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          className="hidden"
                          disabled={uploadingPhoto}
                        />
                      </label>
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-gray-900">
                        {currentUser?.displayName || 'User'}
                      </h4>
                      <p className="text-sm text-gray-500">{currentUser?.email}</p>
                      <label className="text-sm text-blue-600 hover:text-blue-700 font-medium mt-1 cursor-pointer">
                        Change photo
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          className="hidden"
                          disabled={uploadingPhoto}
                        />
                      </label>
                      <p className="text-xs text-gray-400 mt-1">
                        Max 5MB • JPG, PNG, GIF, WebP
                      </p>
                    </div>
                  </div>

                  <form onSubmit={handleUpdateProfile} className="space-y-6">
                    {/* Display Name */}
                    <div>
                      <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-2">
                        Display Name
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          id="displayName"
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter your display name"
                          disabled={loading}
                        />
                      </div>
                    </div>

                    {/* Email */}
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="email"
                          id="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter your email"
                          disabled={loading}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Changing your email will require verification
                      </p>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
                    >
                      <Save className="w-4 h-4" />
                      <span>{loading ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="p-6">
                <div className="max-w-2xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">Security Settings</h3>
                  
                  <form onSubmit={handleUpdatePassword} className="space-y-6">
                    {/* Current Password */}
                    <div>
                      <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 mb-2">
                        Current Password
                      </label>
                      <div className="relative">
                        <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type={showCurrentPassword ? 'text' : 'password'}
                          id="currentPassword"
                          value={currentPassword}
                          onChange={(e) => setCurrentPassword(e.target.value)}
                          className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter current password"
                          disabled={loading}
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* New Password */}
                    <div>
                      <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-2">
                        New Password
                      </label>
                      <div className="relative">
                        <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type={showNewPassword ? 'text' : 'password'}
                          id="newPassword"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Enter new password"
                          disabled={loading}
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* Confirm Password */}
                    <div>
                      <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                        Confirm New Password
                      </label>
                      <div className="relative">
                        <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          id="confirmPassword"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="Confirm new password"
                          disabled={loading}
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={loading || !currentPassword || !newPassword || !confirmPassword}
                      className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
                    >
                      <Shield className="w-4 h-4" />
                      <span>{loading ? 'Updating...' : 'Update Password'}</span>
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* GitHub Tab */}
            {activeTab === 'github' && (
              <div className="p-6">
                <div className="max-w-2xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">GitHub Configuration</h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Configure your own GitHub repository for file storage. You'll need a personal access token with repository permissions.
                  </p>

                  <div className="space-y-6">
                    {/* Repository Owner */}
                    <div>
                      <label htmlFor="githubOwner" className="block text-sm font-medium text-gray-700 mb-2">
                        Repository Owner (Username)
                      </label>
                      <div className="relative">
                        <Github className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          id="githubOwner"
                          value={githubConfig.owner}
                          onChange={(e) => setGithubConfig({ ...githubConfig, owner: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="e.g., your-username"
                        />
                      </div>
                    </div>

                    {/* Repository Name */}
                    <div>
                      <label htmlFor="githubRepo" className="block text-sm font-medium text-gray-700 mb-2">
                        Repository Name
                      </label>
                      <div className="relative">
                        <HardDrive className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          id="githubRepo"
                          value={githubConfig.repo}
                          onChange={(e) => setGithubConfig({ ...githubConfig, repo: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="e.g., my-storage"
                        />
                      </div>
                    </div>

                    {/* Access Token */}
                    <div>
                      <label htmlFor="githubToken" className="block text-sm font-medium text-gray-700 mb-2">
                        Personal Access Token
                      </label>
                      <div className="relative">
                        <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type={showToken ? 'text' : 'password'}
                          id="githubToken"
                          value={githubConfig.token}
                          onChange={(e) => setGithubConfig({ ...githubConfig, token: e.target.value })}
                          className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                        />
                        <button
                          type="button"
                          onClick={() => setShowToken(!showToken)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          {showToken ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Create a token at{' '}
                        <a 
                          href="https://github.com/settings/tokens" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-700 underline"
                        >
                          GitHub Settings
                        </a>
                        {' '}with 'repo\' permissions
                      </p>
                    </div>

                    {/* Connection Status */}
                    {connectionStatus && (
                      <div className={`p-4 rounded-xl border ${
                        connectionStatus.success 
                          ? 'bg-green-50 border-green-200' 
                          : 'bg-red-50 border-red-200'
                      }`}>
                        <div className="flex items-center space-x-3">
                          {connectionStatus.success ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-red-500" />
                          )}
                          <div className="flex-1">
                            <p className={`text-sm font-medium ${
                              connectionStatus.success ? 'text-green-700' : 'text-red-700'
                            }`}>
                              {connectionStatus.message}
                            </p>
                            {connectionStatus.repoInfo && (
                              <div className="mt-2 text-xs text-green-600">
                                <p>Repository: {connectionStatus.repoInfo.fullName}</p>
                                <p>Visibility: {connectionStatus.repoInfo.private ? 'Private' : 'Public'}</p>
                                <p>Permissions: {connectionStatus.repoInfo.permissions?.push ? 'Write' : 'Read'}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-3">
                      <button
                        onClick={handleTestConnection}
                        disabled={testingConnection || !githubConfig.owner || !githubConfig.repo || !githubConfig.token}
                        className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                      >
                        <TestTube className="w-4 h-4" />
                        <span>{testingConnection ? 'Testing...' : 'Test Connection'}</span>
                      </button>

                      <button
                        onClick={handleSaveGitHubConfig}
                        disabled={!githubConfig.owner || !githubConfig.repo || !githubConfig.token}
                        className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Configuration</span>
                      </button>

                      <button
                        onClick={handleResetToDefault}
                        className="flex items-center space-x-2 px-4 py-2 bg-orange-100 text-orange-700 font-medium rounded-xl hover:bg-orange-200 transition-all duration-200"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Reset to Default</span>
                      </button>
                    </div>

                    {/* Help Section */}
                    <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                      <h4 className="text-sm font-semibold text-blue-900 mb-2">How to set up your repository:</h4>
                      <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
                        <li>Create a new repository on GitHub (can be public or private)</li>
                        <li>Go to GitHub Settings → Developer settings → Personal access tokens</li>
                        <li>Generate a new token with 'repo' permissions</li>
                        <li>Copy the token and paste it above</li>
                        <li>Test the connection to verify everything works</li>
                      </ol>
                      <div className="mt-3">
                        <a 
                          href="https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center space-x-1 text-xs text-blue-600 hover:text-blue-700 underline"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>Learn more about personal access tokens</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Preferences Tab */}
            {activeTab === 'preferences' && (
              <div className="p-6">
                <div className="max-w-2xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">Preferences</h3>
                  
                  <div className="space-y-8">
                    {/* Notifications */}
                    <div>
                      <h4 className="text-base font-medium text-gray-900 mb-4">Notifications</h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Bell className="w-5 h-5 text-gray-400" />
                            <div>
                              <p className="text-sm font-medium text-gray-900">Email Notifications</p>
                              <p className="text-xs text-gray-500">Receive updates via email</p>
                            </div>
                          </div>
                          <button
                            onClick={() => setEmailNotifications(!emailNotifications)}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                              emailNotifications ? 'bg-blue-600' : 'bg-gray-200'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                emailNotifications ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Bell className="w-5 h-5 text-gray-400" />
                            <div>
                              <p className="text-sm font-medium text-gray-900">Push Notifications</p>
                              <p className="text-xs text-gray-500">Receive browser notifications</p>
                            </div>
                          </div>
                          <button
                            onClick={() => setPushNotifications(!pushNotifications)}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                              pushNotifications ? 'bg-blue-600' : 'bg-gray-200'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                pushNotifications ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Theme */}
                    <div>
                      <h4 className="text-base font-medium text-gray-900 mb-4">Appearance</h4>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Theme</label>
                          <select
                            value={theme}
                            onChange={(e) => setTheme(e.target.value)}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          >
                            <option value="light">Light</option>
                            <option value="dark">Dark</option>
                            <option value="system">System</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>
                          <select
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          >
                            <option value="en">English</option>
                            <option value="es">Español</option>
                            <option value="fr">Français</option>
                            <option value="de">Deutsch</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Storage Tab */}
            {activeTab === 'storage' && (
              <div className="p-6">
                <div className="max-w-2xl">
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">Storage Information</h3>
                  
                  <div className="space-y-6">
                    {/* Storage Usage */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-base font-medium text-gray-900">GitHub Repository</h4>
                        <HardDrive className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Repository</span>
                          <span className="font-medium">{githubConfig.owner}/{githubConfig.repo}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Branch</span>
                          <span className="font-medium">main</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
                          <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full w-1/3"></div>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          Storage usage depends on your GitHub repository limits
                        </p>
                      </div>
                    </div>

                    {/* Repository Info */}
                    <div className="border border-gray-200 rounded-xl p-6">
                      <h4 className="text-base font-medium text-gray-900 mb-4">Repository Settings</h4>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Owner</span>
                          <span className="font-medium">{githubConfig.owner}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Repository</span>
                          <span className="font-medium">{githubConfig.repo}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">API Access</span>
                          <span className="font-medium text-green-600">
                            {githubConfig.token ? 'Configured' : 'Not configured'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Profile Photos</span>
                          <span className="font-medium text-blue-600">profile/ folder</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};