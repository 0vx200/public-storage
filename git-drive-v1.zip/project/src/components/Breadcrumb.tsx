import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  name: string;
  path: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  onNavigate: (path: string) => void;
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items, onNavigate }) => {
  return (
    <nav className="flex items-center space-x-1 text-sm overflow-x-auto scrollbar-hide">
      <div className="flex items-center space-x-1 flex-shrink-0">
        {items.map((item, index) => (
          <React.Fragment key={item.path}>
            {index > 0 && <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 text-gray-300 flex-shrink-0" />}
            <button
              onClick={() => onNavigate(item.path)}
              className={`flex items-center space-x-1 sm:space-x-2 px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg transition-all duration-200 whitespace-nowrap ${
                index === items.length - 1 
                  ? 'text-gray-900 font-semibold bg-gray-100' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              {index === 0 && <Home className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />}
              <span className="text-xs sm:text-sm truncate max-w-[100px] sm:max-w-none">
                {item.name}
              </span>
            </button>
          </React.Fragment>
        ))}
      </div>
    </nav>
  );
};