// GitHub Service with configurable settings
const GITHUB_API_BASE = 'https://api.github.com';

// Default settings (fallback)
const DEFAULT_REPO_OWNER = '0vx200';
const DEFAULT_REPO_NAME = 'public-storage';
const DEFAULT_ACCESS_TOKEN = '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';

export interface GitHubConfig {
  owner: string;
  repo: string;
  token: string;
}

export class GitHubService {
  private static getConfig(): GitHubConfig {
    const savedConfig = localStorage.getItem('github-config');
    if (savedConfig) {
      try {
        return JSON.parse(savedConfig);
      } catch (error) {
        console.error('Error parsing GitHub config:', error);
      }
    }
    
    // Return default config
    return {
      owner: DEFAULT_REPO_OWNER,
      repo: DEFAULT_REPO_NAME,
      token: DEFAULT_ACCESS_TOKEN
    };
  }

  static saveConfig(config: GitHubConfig): void {
    localStorage.setItem('github-config', JSON.stringify(config));
  }

  static resetToDefault(): void {
    localStorage.removeItem('github-config');
  }

  private static getHeaders(): Record<string, string> {
    const config = this.getConfig();
    return {
      'Authorization': `token ${config.token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/vnd.github.v3+json'
    };
  }

  private static getRepoUrl(path = ''): string {
    const config = this.getConfig();
    return `${GITHUB_API_BASE}/repos/${config.owner}/${config.repo}/contents/${path}`;
  }

  static async testConnection(): Promise<{ success: boolean; message: string; repoInfo?: any }> {
    try {
      const config = this.getConfig();
      const response = await fetch(`${GITHUB_API_BASE}/repos/${config.owner}/${config.repo}`, {
        headers: this.getHeaders()
      });

      if (!response.ok) {
        if (response.status === 401) {
          return { success: false, message: 'Invalid access token' };
        } else if (response.status === 404) {
          return { success: false, message: 'Repository not found' };
        } else {
          return { success: false, message: `GitHub API error: ${response.status}` };
        }
      }

      const repoInfo = await response.json();
      return { 
        success: true, 
        message: 'Connection successful', 
        repoInfo: {
          name: repoInfo.name,
          fullName: repoInfo.full_name,
          private: repoInfo.private,
          permissions: repoInfo.permissions
        }
      };
    } catch (error) {
      console.error('Connection test error:', error);
      return { success: false, message: 'Network error or invalid configuration' };
    }
  }

  static async getFiles(path = ''): Promise<any> {
    const url = this.getRepoUrl(path);
    
    try {
      const response = await fetch(url, { headers: this.getHeaders() });
      if (!response.ok) {
        throw new Error(`GitHub API error: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching files:', error);
      throw error;
    }
  }

  static async uploadFile(path: string, content: string, message = 'Upload file'): Promise<any> {
    const url = this.getRepoUrl(path);
    
    try {
      const response = await fetch(url, {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify({
          message,
          content,
          branch: 'main'
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Upload failed: ${response.status} - ${errorData.message || 'Unknown error'}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  }

  static async deleteFile(path: string, sha: string, message = 'Delete file'): Promise<any> {
    const url = this.getRepoUrl(path);
    
    try {
      const response = await fetch(url, {
        method: 'DELETE',
        headers: this.getHeaders(),
        body: JSON.stringify({
          message,
          sha,
          branch: 'main'
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Delete failed: ${response.status} - ${errorData.message || 'Unknown error'}`);
      }
      
      // GitHub returns 200 for successful deletion
      if (response.status === 200) {
        return await response.json();
      }
      
      return { success: true };
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }

  static async deleteFolder(path: string): Promise<any> {
    try {
      // Get all files in the folder first
      const files = await this.getFiles(path);
      
      if (!Array.isArray(files)) {
        throw new Error('Invalid folder structure');
      }

      // Delete all files in the folder recursively
      const deletePromises = files.map(async (file) => {
        if (file.type === 'dir') {
          // Recursively delete subdirectories
          return this.deleteFolder(file.path);
        } else {
          // Delete individual files
          return this.deleteFile(file.path, file.sha, `Delete ${file.name}`);
        }
      });

      await Promise.all(deletePromises);
      return { success: true, message: 'Folder deleted successfully' };
    } catch (error) {
      console.error('Error deleting folder:', error);
      throw error;
    }
  }

  static async createFolder(path: string): Promise<any> {
    // GitHub doesn't have folders, so we create a .gitkeep file
    const keepFile = `${path}/.gitkeep`;
    return this.uploadFile(keepFile, '', `Create folder ${path}`);
  }

  static async uploadProfilePhoto(userId: string, imageBase64: string, fileName: string): Promise<any> {
    const profilePath = `profile/${userId}/${fileName}`;
    return this.uploadFile(profilePath, imageBase64, `Update profile photo for ${userId}`);
  }

  static async getProfilePhoto(userId: string): Promise<string | null> {
    try {
      // First test if the GitHub configuration is valid
      const connectionTest = await this.testConnection();
      if (!connectionTest.success) {
        console.warn('GitHub configuration is invalid, skipping profile photo load');
        return null;
      }

      const profileFolder = await this.getFiles(`profile/${userId}`);
      if (Array.isArray(profileFolder)) {
        // Find the first image file in the profile folder
        const imageFile = profileFolder.find(file => 
          file.type === 'file' && 
          /\.(jpg|jpeg|png|gif|webp)$/i.test(file.name)
        );
        if (imageFile) {
          const config = this.getConfig();
          return `https://raw.githubusercontent.com/${config.owner}/${config.repo}/main/${imageFile.path}`;
        }
      }
      return null;
    } catch (error) {
      // Don't log 404 errors as they're expected when profile folder doesn't exist
      if (error instanceof Error && error.message.includes('GitHub API error: 404')) {
        return null;
      }
      console.error('Error getting profile photo:', error);
      return null;
    }
  }

  static async deleteProfilePhoto(userId: string, fileName: string, sha: string): Promise<any> {
    const profilePath = `profile/${userId}/${fileName}`;
    return this.deleteFile(profilePath, sha, `Delete profile photo for ${userId}`);
  }

  static getCurrentConfig(): GitHubConfig {
    return this.getConfig();
  }
}