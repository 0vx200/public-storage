// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAOamGcmov0GenyFIYZjd0Cxj6e2k_3I4M",
  authDomain: "github-drive-f6a7a.firebaseapp.com",
  projectId: "github-drive-f6a7a",
  storageBucket: "github-drive-f6a7a.firebasestorage.app",
  messagingSenderId: "49835340982",
  appId: "1:49835340982:web:c07401d26f2da794f5e217",
  measurementId: "G-JKGJYVERGM"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);

export { auth, analytics };
export default app;