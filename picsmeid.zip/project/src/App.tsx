import React from 'react';
import ImageUploader from './components/ImageUploader';

function App() {
  return <ImageUploader />;
}

export default App;