import React from 'react';
import { Camera } from 'lucide-react';

interface FooterProps {
  onShowTerms?: () => void;
  onShowPrivacy?: () => void;
}

export default function Footer({ onShowTerms, onShowPrivacy }: FooterProps) {
  return (
    <footer className="bg-white border-t border-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">PicsMe</span>
          </div>
          <p className="text-gray-600 mb-6">
            Powered by GitHub
          </p>
          
          {/* Navigation Links */}
          <div className="flex items-center justify-center space-x-6 text-sm">
            {onShowTerms && (
              <button
                onClick={onShowTerms}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                Terms of Service
              </button>
            )}
            {onShowPrivacy && (
              <button
                onClick={onShowPrivacy}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                Privacy Policy
              </button>
            )}
            <a
              href="https://github.com/lineavv/picsme"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              GitHub
            </a>
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-400">
              © {new Date().getFullYear()} PicsMe. Free image hosting service.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}