import React, { useState, useEffect } from 'react';
import { Image, Copy, Check, ExternalLink, RefreshCw, ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react';

interface RepoImage {
  name: string;
  url: string;
  downloadUrl: string;
  size: number;
  sha: string;
}

interface ImageGalleryProps {
  onBack: () => void;
}

export default function ImageGallery({ onBack }: ImageGalleryProps) {
  const [repoImages, setRepoImages] = useState<RepoImage[]>([]);
  const [loadingRepoImages, setLoadingRepoImages] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [imagesPerPage] = useState(20); // Increased back for smaller cards

  // Fixed GitHub configuration
  const githubConfig = {
    token: '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',
    owner: 'lineavv',
    repo: 'picsme',
    path: 'uploader'
  };

  useEffect(() => {
    loadRepoImages();
  }, []);

  const loadRepoImages = async () => {
    setLoadingRepoImages(true);
    try {
      const apiUrl = `https://api.github.com/repos/${githubConfig.owner}/${githubConfig.repo}/contents/${githubConfig.path}`;
      
      const response = await fetch(apiUrl, {
        headers: {
          'Authorization': `Bearer ${githubConfig.token}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'PicsMe-Uploader/1.0',
        },
      });

      if (response.ok) {
        const files = await response.json();
        const imageFiles = files
          .filter((file: any) => 
            file.type === 'file' && 
            /\.(jpg|jpeg|png|gif|webp)$/i.test(file.name)
          )
          .map((file: any) => ({
            name: file.name,
            url: `https://raw.githubusercontent.com/${githubConfig.owner}/${githubConfig.repo}/main/${file.path}`,
            downloadUrl: file.download_url,
            size: file.size,
            sha: file.sha
          }))
          .sort((a: RepoImage, b: RepoImage) => b.name.localeCompare(a.name));

        setRepoImages(imageFiles);
      }
    } catch (error) {
      console.error('Failed to load repository images:', error);
    } finally {
      setLoadingRepoImages(false);
    }
  };

  const copyToClipboard = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(null), 2000);
    } catch (error) {
      console.error('Failed to copy URL:', error);
    }
  };

  const openInNewTab = (url: string) => {
    window.open(url, '_blank');
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Pagination logic
  const totalPages = Math.ceil(repoImages.length / imagesPerPage);
  const startIndex = (currentPage - 1) * imagesPerPage;
  const endIndex = startIndex + imagesPerPage;
  const currentImages = repoImages.slice(startIndex, endIndex);

  const goToPage = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goToPrevPage = () => {
    if (currentPage > 1) {
      goToPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      goToPage(currentPage + 1);
    }
  };

  // Generate page numbers for pagination
  const getPageNumbers = () => {
    const pages = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= 4; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1);
        pages.push('...');
        for (let i = totalPages - 3; i <= totalPages; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        pages.push('...');
        for (let i = currentPage - 1; i <= currentPage + 1; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(totalPages);
      }
    }
    
    return pages;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Back to Upload</span>
                <span className="sm:hidden">Back</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900">Gallery</h1>
                <p className="text-xs text-gray-500 hidden sm:block">
                  {repoImages.length} images • Page {currentPage} of {totalPages}
                </p>
              </div>
            </div>
            <button
              onClick={loadRepoImages}
              disabled={loadingRepoImages}
              className="inline-flex items-center px-3 py-2 bg-blue-100 text-blue-700 rounded-lg font-medium hover:bg-blue-200 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${loadingRepoImages ? 'animate-spin' : ''} sm:mr-2`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 py-4 sm:py-8">
        {loadingRepoImages ? (
          <div className="text-center py-16">
            <div className="w-12 h-12 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <RefreshCw className="w-6 h-6 text-blue-600 animate-spin" />
            </div>
            <p className="text-lg text-gray-600">Loading images...</p>
          </div>
        ) : repoImages.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Image className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">No images found</h2>
            <p className="text-gray-600">Upload some images to see them here</p>
          </div>
        ) : (
          <>
            {/* Images Grid - Smaller, more compact cards */}
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 2xl:grid-cols-8 gap-3 sm:gap-4 mb-8">
              {currentImages.map((image, index) => (
                <div
                  key={`${image.name}-${index}`}
                  className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-200 group hover:scale-105"
                >
                  {/* Image container - Smaller aspect ratio */}
                  <div className="aspect-square bg-gray-100 relative overflow-hidden">
                    <img
                      src={image.url}
                      alt={image.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      loading="lazy"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        const parent = target.parentElement;
                        if (parent) {
                          parent.innerHTML = `
                            <div class="w-full h-full flex items-center justify-center">
                              <div class="text-center">
                                <div class="w-6 h-6 sm:w-8 sm:h-8 mx-auto bg-gray-300 rounded-lg flex items-center justify-center mb-1">
                                  <svg class="w-3 h-3 sm:w-4 sm:h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                  </svg>
                                </div>
                                <p class="text-xs text-gray-500">Error</p>
                              </div>
                            </div>
                          `;
                        }
                      }}
                    />
                  </div>
                  
                  {/* Card content - Compact padding */}
                  <div className="p-2 sm:p-3">
                    <h3 className="font-medium text-gray-900 truncate text-xs sm:text-sm mb-1" title={image.name}>
                      {image.name}
                    </h3>
                    <p className="text-xs text-gray-500 mb-2 hidden sm:block">{formatFileSize(image.size)}</p>
                    
                    {/* Action buttons - Compact layout */}
                    <div className="space-y-1 sm:space-y-2">
                      <button
                        onClick={() => openInNewTab(image.url)}
                        className="w-full flex items-center justify-center px-2 py-1 sm:py-1.5 bg-gray-100 text-gray-700 rounded text-xs font-medium hover:bg-gray-200 transition-colors"
                        title="Open image"
                      >
                        <ExternalLink className="w-3 h-3 sm:mr-1" />
                        <span className="hidden sm:inline ml-1">View</span>
                      </button>
                      <button
                        onClick={() => copyToClipboard(image.url)}
                        className={`w-full flex items-center justify-center px-2 py-1 sm:py-1.5 rounded text-xs font-medium transition-colors ${
                          copiedUrl === image.url
                            ? 'bg-green-100 text-green-700'
                            : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                        }`}
                        title="Copy URL"
                      >
                        {copiedUrl === image.url ? (
                          <>
                            <Check className="w-3 h-3 sm:mr-1" />
                            <span className="hidden sm:inline ml-1">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3 sm:mr-1" />
                            <span className="hidden sm:inline ml-1">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center space-x-1 sm:space-x-2">
                <button
                  onClick={goToPrevPage}
                  disabled={currentPage === 1}
                  className="flex items-center px-2 sm:px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4 sm:mr-1" />
                  <span className="hidden sm:inline">Previous</span>
                </button>

                <div className="flex space-x-1">
                  {getPageNumbers().map((page, index) => (
                    <React.Fragment key={index}>
                      {page === '...' ? (
                        <span className="px-2 sm:px-3 py-2 text-sm text-gray-500">...</span>
                      ) : (
                        <button
                          onClick={() => goToPage(page as number)}
                          className={`px-2 sm:px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                            currentPage === page
                              ? 'bg-blue-600 text-white'
                              : 'text-gray-700 bg-white border border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          {page}
                        </button>
                      )}
                    </React.Fragment>
                  ))}
                </div>

                <button
                  onClick={goToNextPage}
                  disabled={currentPage === totalPages}
                  className="flex items-center px-2 sm:px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span className="hidden sm:inline">Next</span>
                  <ChevronRight className="w-4 h-4 sm:ml-1" />
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}