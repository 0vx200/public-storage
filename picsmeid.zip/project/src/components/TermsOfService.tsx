import React from 'react';
import { ArrowLeft, Shield, FileText } from 'lucide-react';

interface TermsOfServiceProps {
  onBack: () => void;
}

export default function TermsOfService({ onBack }: TermsOfServiceProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Home</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <h1 className="text-xl font-bold text-gray-900">Terms of Service</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <div className="prose prose-gray max-w-none">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Terms of Service</h1>
              <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
            </div>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Acceptance of Terms</h2>
                <p className="text-gray-700 leading-relaxed">
                  By accessing and using PicsMe ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. 
                  If you do not agree to abide by the above, please do not use this service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Service Description</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  PicsMe is a free image hosting service that allows users to upload images and receive public URLs for sharing. 
                  The service is provided "as is" without any warranties.
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Maximum file size: 10MB per image</li>
                  <li>Supported formats: JPEG, PNG, GIF, WebP</li>
                  <li>No registration required</li>
                  <li>Custom filename support</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. User Responsibilities</h2>
                <p className="text-gray-700 leading-relaxed mb-4">You agree not to upload content that:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Is illegal, harmful, threatening, abusive, or defamatory</li>
                  <li>Violates intellectual property rights</li>
                  <li>Contains malware or malicious code</li>
                  <li>Is pornographic or sexually explicit</li>
                  <li>Promotes violence or discrimination</li>
                  <li>Violates privacy rights of others</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Content Policy</h2>
                <p className="text-gray-700 leading-relaxed">
                  We reserve the right to remove any content that violates these terms without notice. 
                  Users are solely responsible for the content they upload and must ensure they have the right to share such content.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Service Availability</h2>
                <p className="text-gray-700 leading-relaxed">
                  While we strive to maintain high availability, we do not guarantee uninterrupted service. 
                  The service may be temporarily unavailable for maintenance, updates, or due to technical issues.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Data Retention</h2>
                <p className="text-gray-700 leading-relaxed">
                  Uploaded images are stored on GitHub repositories and are publicly accessible via direct URLs. 
                  We do not guarantee permanent storage and reserve the right to remove content at any time.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Limitation of Liability</h2>
                <p className="text-gray-700 leading-relaxed">
                  PicsMe and its operators shall not be liable for any direct, indirect, incidental, special, 
                  or consequential damages resulting from the use or inability to use the service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Changes to Terms</h2>
                <p className="text-gray-700 leading-relaxed">
                  We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting. 
                  Continued use of the service constitutes acceptance of modified terms.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. Contact Information</h2>
                <p className="text-gray-700 leading-relaxed">
                  If you have any questions about these Terms of Service, please contact us through our GitHub repository 
                  or create an issue for support.
                </p>
              </section>
            </div>

            <div className="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-start space-x-3">
                <Shield className="w-6 h-6 text-blue-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-blue-900 mb-2">Important Notice</h3>
                  <p className="text-blue-800">
                    By using PicsMe, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. 
                    This service is provided free of charge and without warranty.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}