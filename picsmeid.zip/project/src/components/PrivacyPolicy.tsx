import React from 'react';
import { ArrowLeft, Shield, Lock } from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

export default function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Home</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Lock className="w-5 h-5 text-green-600" />
                </div>
                <h1 className="text-xl font-bold text-gray-900">Privacy Policy</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <div className="prose prose-gray max-w-none">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
              <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
            </div>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Information We Collect</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  PicsMe is designed to be privacy-friendly. We collect minimal information to provide our service:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li><strong>Images:</strong> The images you upload to our service</li>
                  <li><strong>Technical Data:</strong> Basic server logs for service maintenance</li>
                  <li><strong>No Personal Data:</strong> We do not require registration or collect personal information</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. How We Use Your Information</h2>
                <p className="text-gray-700 leading-relaxed mb-4">The information we collect is used solely to:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Provide image hosting services</li>
                  <li>Generate public URLs for your uploaded images</li>
                  <li>Maintain service functionality and performance</li>
                  <li>Prevent abuse and ensure service security</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. Data Storage and Security</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Your uploaded images are stored on GitHub repositories, which provides:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Secure cloud storage infrastructure</li>
                  <li>Global content delivery network (CDN)</li>
                  <li>Reliable backup and redundancy</li>
                  <li>Industry-standard security measures</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mt-4">
                  <strong>Important:</strong> All uploaded images become publicly accessible via direct URLs. 
                  Do not upload sensitive or private content.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Public Nature of Content</h2>
                <p className="text-gray-700 leading-relaxed">
                  By design, all images uploaded to PicsMe are publicly accessible. This means:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 mt-4">
                  <li>Anyone with the URL can view your images</li>
                  <li>Images may be indexed by search engines</li>
                  <li>Content is not password-protected or private</li>
                  <li>You should only upload content you're comfortable sharing publicly</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Cookies and Tracking</h2>
                <p className="text-gray-700 leading-relaxed">
                  PicsMe does not use cookies for tracking or analytics. We do not track user behavior, 
                  create user profiles, or use third-party analytics services.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Third-Party Services</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Our service relies on GitHub for storage. Please review GitHub's privacy policy for information 
                  about how they handle data:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>GitHub Privacy Statement: <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">docs.github.com/privacy</a></li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Data Retention</h2>
                <p className="text-gray-700 leading-relaxed">
                  Images are stored indefinitely unless removed by us for policy violations or technical reasons. 
                  We do not provide user-initiated deletion functionality at this time.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Children's Privacy</h2>
                <p className="text-gray-700 leading-relaxed">
                  Our service is not directed to children under 13. We do not knowingly collect personal information 
                  from children under 13. If you believe a child has uploaded content, please contact us.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. International Users</h2>
                <p className="text-gray-700 leading-relaxed">
                  PicsMe is accessible globally. By using our service, you consent to the transfer and processing 
                  of your data in accordance with this privacy policy.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">10. Changes to Privacy Policy</h2>
                <p className="text-gray-700 leading-relaxed">
                  We may update this privacy policy from time to time. Changes will be posted on this page with 
                  an updated revision date. Continued use of the service constitutes acceptance of any changes.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">11. Contact Us</h2>
                <p className="text-gray-700 leading-relaxed">
                  If you have questions about this privacy policy or our data practices, please contact us 
                  through our GitHub repository.
                </p>
              </section>
            </div>

            <div className="mt-12 p-6 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-start space-x-3">
                <Shield className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-green-900 mb-2">Privacy Commitment</h3>
                  <p className="text-green-800">
                    We are committed to protecting your privacy. PicsMe collects minimal data and does not track users. 
                    Remember that all uploaded content is publicly accessible.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}