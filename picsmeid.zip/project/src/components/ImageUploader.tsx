import React, { useState, useCallback, useEffect } from 'react';
import { Upload, Image, Copy, Check, AlertCircle, X, ExternalLink, Edit3, Zap, Globe } from 'lucide-react';
import Footer from './Footer';
import ImageGallery from './ImageGallery';
import Navbar from './Navbar';
import TermsOfService from './TermsOfService';
import PrivacyPolicy from './PrivacyPolicy';

interface UploadedImage {
  id: string;
  name: string;
  url: string;
  size: number;
  timestamp: Date;
  filename: string;
  customName?: string;
}

interface RepoImage {
  name: string;
  url: string;
  downloadUrl: string;
  size: number;
  sha: string;
}

interface UploadStatus {
  uploading: boolean;
  progress: number;
  error: string | null;
  success: boolean;
}

export default function ImageUploader() {
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>({
    uploading: false,
    progress: 0,
    error: null,
    success: false
  });
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [repoImages, setRepoImages] = useState<RepoImage[]>([]);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [customFilename, setCustomFilename] = useState('');
  const [showCustomName, setShowCustomName] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showGallery, setShowGallery] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  // Fixed GitHub configuration - hidden from users
  const githubConfig = {
    token: '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',
    owner: 'lineavv',
    repo: 'picsme',
    path: 'uploader'
  };

  // Load repository images count on component mount
  useEffect(() => {
    loadRepoImagesCount();
  }, []);

  const loadRepoImagesCount = async () => {
    try {
      const apiUrl = `https://api.github.com/repos/${githubConfig.owner}/${githubConfig.repo}/contents/${githubConfig.path}`;
      
      const response = await fetch(apiUrl, {
        headers: {
          'Authorization': `Bearer ${githubConfig.token}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'PicsMe-Uploader/1.0',
        },
      });

      if (response.ok) {
        const files = await response.json();
        const imageFiles = files
          .filter((file: any) => 
            file.type === 'file' && 
            /\.(jpg|jpeg|png|gif|webp)$/i.test(file.name)
          )
          .map((file: any) => ({
            name: file.name,
            url: `https://raw.githubusercontent.com/${githubConfig.owner}/${githubConfig.repo}/main/${file.path}`,
            downloadUrl: file.download_url,
            size: file.size,
            sha: file.sha
          }));

        setRepoImages(imageFiles);
      }
    } catch (error) {
      console.error('Failed to load repository images count:', error);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const validateFile = (file: File): string | null => {
    const maxSize = 10 * 1024 * 1024; // 10MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    
    if (!allowedTypes.includes(file.type)) {
      return 'Only JPEG, PNG, GIF, and WebP images are supported';
    }
    
    if (file.size > maxSize) {
      return 'Image size must be less than 10MB';
    }
    
    return null;
  };

  const checkFileExists = async (filename: string): Promise<boolean> => {
    const filePath = `${githubConfig.path}/${filename}`;
    const apiUrl = `https://api.github.com/repos/${githubConfig.owner}/${githubConfig.repo}/contents/${filePath}`;

    try {
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${githubConfig.token}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'PicsMe-Uploader/1.0',
        },
      });
      
      return response.status === 200;
    } catch (error) {
      return false;
    }
  };

  const generateFilename = async (originalName: string, customName?: string): Promise<string> => {
    const extension = originalName.split('.').pop()?.toLowerCase() || 'jpg';
    
    if (customName && customName.trim()) {
      // Clean custom name - remove special characters and spaces, keep it simple
      const cleanName = customName.trim()
        .replace(/[^a-zA-Z0-9\-_]/g, '')
        .toLowerCase();
      
      if (cleanName) {
        let finalFilename = `${cleanName}.${extension}`;
        let counter = 1;
        
        // Check if file exists and increment counter if needed
        while (await checkFileExists(finalFilename)) {
          finalFilename = `${cleanName}${counter}.${extension}`;
          counter++;
        }
        
        return finalFilename;
      }
    }
    
    // Fallback to timestamp-based naming
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substring(2, 8);
    return `image_${timestamp}_${randomId}.${extension}`;
  };

  const uploadToGitHub = async (file: File, customName?: string): Promise<{ url: string; filename: string }> => {
    // Convert file to base64
    const base64 = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.readAsDataURL(file);
    });

    const filename = await generateFilename(file.name, customName);
    const filePath = `${githubConfig.path}/${filename}`;
    
    // GitHub API URL
    const apiUrl = `https://api.github.com/repos/${githubConfig.owner}/${githubConfig.repo}/contents/${filePath}`;

    const response = await fetch(apiUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${githubConfig.token}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'PicsMe-Uploader/1.0',
      },
      body: JSON.stringify({
        message: `Upload image: ${filename}`,
        content: base64,
        branch: 'main'
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (response.status === 401) {
        throw new Error('Service temporarily unavailable. Please try again later.');
      } else if (response.status === 404) {
        throw new Error('Service configuration error. Please contact support.');
      } else if (response.status === 403) {
        throw new Error('Upload limit reached. Please try again later.');
      }
      throw new Error(errorData.message || `Upload failed. Please try again.`);
    }

    // Generate public URL
    const publicUrl = `https://raw.githubusercontent.com/${githubConfig.owner}/${githubConfig.repo}/main/${filePath}`;

    return {
      url: publicUrl,
      filename
    };
  };

  const handleFileSelection = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const file = files[0];
    const validationError = validateFile(file);
    
    if (validationError) {
      setUploadStatus({
        uploading: false,
        progress: 0,
        error: validationError,
        success: false
      });
      return;
    }

    setSelectedFile(file);
    setShowCustomName(true);
    setCustomFilename('');
  };

  const handleUpload = async (useCustomName: boolean = false) => {
    if (!selectedFile) return;

    setShowCustomName(false);
    setUploadStatus({
      uploading: true,
      progress: 0,
      error: null,
      success: false
    });

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setUploadStatus(prev => ({
          ...prev,
          progress: Math.min(prev.progress + 15, 90)
        }));
      }, 300);

      const finalCustomName = useCustomName ? customFilename : undefined;
      const { url, filename } = await uploadToGitHub(selectedFile, finalCustomName);
      
      clearInterval(progressInterval);
      
      const newImage: UploadedImage = {
        id: Date.now().toString(),
        name: selectedFile.name,
        url,
        filename,
        size: selectedFile.size,
        timestamp: new Date(),
        customName: finalCustomName
      };

      setUploadedImages(prev => [newImage, ...prev]);
      setUploadStatus({
        uploading: false,
        progress: 100,
        error: null,
        success: true
      });

      // Reset states
      setSelectedFile(null);
      setCustomFilename('');

      // Reload repository images count to show the new upload
      loadRepoImagesCount();

      // Reset success state after 3 seconds
      setTimeout(() => {
        setUploadStatus(prev => ({ ...prev, success: false, progress: 0 }));
      }, 3000);

    } catch (error) {
      setUploadStatus({
        uploading: false,
        progress: 0,
        error: error instanceof Error ? error.message : 'Upload failed. Please try again.',
        success: false
      });
      setShowCustomName(false);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    handleFileSelection(e.dataTransfer.files);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileSelection(e.target.files);
  };

  const copyToClipboard = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(null), 2000);
    } catch (error) {
      console.error('Failed to copy URL:', error);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const clearError = () => {
    setUploadStatus(prev => ({ ...prev, error: null }));
    setShowCustomName(false);
    setSelectedFile(null);
  };

  const openInNewTab = (url: string) => {
    window.open(url, '_blank');
  };

  // Show different pages based on state
  if (showGallery) {
    return <ImageGallery onBack={() => setShowGallery(false)} />;
  }

  if (showTerms) {
    return <TermsOfService onBack={() => setShowTerms(false)} />;
  }

  if (showPrivacy) {
    return <PrivacyPolicy onBack={() => setShowPrivacy(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <Navbar 
        onShowGallery={() => setShowGallery(true)}
        totalImages={repoImages.length}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Upload Images, Get Instant URLs
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Professional image hosting service with instant public URLs. No registration required, 
            custom filenames supported, and reliable worldwide access.
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-2xl mx-auto mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">10MB</div>
              <div className="text-sm text-gray-500">Max File Size</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">Free</div>
              <div className="text-sm text-gray-500">Always</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">Instant</div>
              <div className="text-sm text-gray-500">Upload Speed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{repoImages.length}</div>
              <div className="text-sm text-gray-500">Total Images</div>
            </div>
          </div>
        </div>

        {/* Custom Filename Modal */}
        {showCustomName && selectedFile && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4 shadow-2xl">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Customize Filename</h3>
              <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Selected file:</p>
                <p className="font-medium text-gray-900 truncate">{selectedFile.name}</p>
                <p className="text-xs text-gray-500">{formatFileSize(selectedFile.size)}</p>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Custom filename (optional)
                </label>
                <input
                  type="text"
                  value={customFilename}
                  onChange={(e) => setCustomFilename(e.target.value)}
                  placeholder="usdt"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  maxLength={30}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Contoh: "usdt" akan menjadi "usdt.png" atau "usdt1.png" jika sudah ada
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => handleUpload(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Auto Name
                </button>
                <button
                  onClick={() => handleUpload(true)}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Use Custom
                </button>
              </div>
              
              <button
                onClick={() => {
                  setShowCustomName(false);
                  setSelectedFile(null);
                  setCustomFilename('');
                }}
                className="w-full mt-3 px-4 py-2 text-gray-500 hover:text-gray-700 transition-colors text-sm"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Upload Area */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
          <div className="p-6 lg:p-8">
            <div
              className={`relative border-2 border-dashed rounded-lg p-8 lg:p-12 text-center transition-all duration-200 ${
                dragActive
                  ? 'border-blue-500 bg-blue-50'
                  : uploadStatus.success
                  ? 'border-green-500 bg-green-50'
                  : uploadStatus.error
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp"
                onChange={handleInputChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={uploadStatus.uploading}
              />
              
              <div className="space-y-4">
                {uploadStatus.uploading ? (
                  <>
                    <div className="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-blue-600 animate-bounce" />
                    </div>
                    <div className="space-y-3">
                      <p className="text-xl font-semibold text-gray-900">Uploading...</p>
                      <div className="w-full max-w-xs mx-auto bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${uploadStatus.progress}%` }}
                        />
                      </div>
                      <p className="text-sm text-gray-500">{uploadStatus.progress}% complete</p>
                    </div>
                  </>
                ) : uploadStatus.success ? (
                  <>
                    <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <div className="space-y-2">
                      <p className="text-xl font-semibold text-green-900">Upload successful!</p>
                      <p className="text-green-600">Your image is now publicly accessible</p>
                    </div>
                  </>
                ) : uploadStatus.error ? (
                  <>
                    <div className="w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center">
                      <AlertCircle className="w-8 h-8 text-red-600" />
                    </div>
                    <div className="space-y-3">
                      <p className="text-xl font-semibold text-red-900">Upload failed</p>
                      <p className="text-red-600 max-w-md mx-auto">{uploadStatus.error}</p>
                      <button
                        onClick={clearError}
                        className="inline-flex items-center px-4 py-2 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 transition-colors"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Try Again
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-gray-400" />
                    </div>
                    <div className="space-y-3">
                      <p className="text-xl font-semibold text-gray-900">
                        Drop your image here or click to browse
                      </p>
                      <p className="text-gray-500">
                        Supports JPEG, PNG, GIF, WebP up to 10MB
                      </p>
                      <div className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                        <Check className="w-4 h-4 mr-1" />
                        Free • No Registration • Custom Names
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Recently Uploaded Images */}
        {uploadedImages.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-semibold text-gray-900 mb-1">Recently Uploaded</h2>
              <p className="text-gray-600">Images uploaded in this session</p>
            </div>
            <div className="p-6 space-y-4">
              {uploadedImages.map((image) => (
                <div
                  key={image.id}
                  className="flex flex-col lg:flex-row lg:items-center lg:justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 space-y-4 lg:space-y-0"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Image className="w-6 h-6 text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-lg font-medium text-gray-900 truncate">{image.name}</h3>
                      <p className="text-sm text-gray-500">
                        {formatFileSize(image.size)} • {image.timestamp.toLocaleString()}
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <p className="text-xs text-gray-400 truncate">File: {image.filename}</p>
                        {image.customName && (
                          <div className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                            <Edit3 className="w-3 h-3 mr-1" />
                            Custom
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3 lg:max-w-2xl">
                    <div className="bg-white rounded-lg border border-gray-200 p-3 flex-1 min-w-0">
                      <code className="text-sm text-gray-700 break-all block">
                        {image.url}
                      </code>
                    </div>
                    <div className="flex space-x-2 flex-shrink-0">
                      <button
                        onClick={() => openInNewTab(image.url)}
                        className="flex items-center justify-center px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                        title="Open image"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => copyToClipboard(image.url)}
                        className={`flex items-center justify-center px-4 py-2 rounded-lg font-medium transition-colors ${
                          copiedUrl === image.url
                            ? 'bg-green-100 text-green-700'
                            : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                        }`}
                      >
                        {copiedUrl === image.url ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-2" />
                            Copy URL
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Instant Upload</h3>
            <p className="text-gray-600">Fast, reliable uploads with real-time progress tracking</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Edit3 className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Custom Names</h3>
            <p className="text-gray-600">Choose your own filenames or use auto-generated ones</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Globe className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Global Access</h3>
            <p className="text-gray-600">Worldwide accessibility with fast loading times</p>
          </div>
        </div>
      </main>

      <Footer 
        onShowTerms={() => setShowTerms(true)}
        onShowPrivacy={() => setShowPrivacy(true)}
      />
    </div>
  );
}