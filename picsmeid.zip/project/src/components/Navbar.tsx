import React from 'react';
import { Camera, Images } from 'lucide-react';

interface NavbarProps {
  onShowGallery: () => void;
  totalImages: number;
}

export default function Navbar({ onShowGallery, totalImages }: NavbarProps) {
  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">PicsMe</h1>
              <p className="text-xs text-gray-500 hidden sm:block">Free Image Hosting</p>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="flex items-center">
            {/* Gallery Button */}
            <button
              onClick={onShowGallery}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg font-medium hover:bg-blue-200 transition-colors"
            >
              <Images className="w-4 h-4" />
              <span className="hidden sm:inline">View Gallery</span>
              <span className="sm:hidden">Gallery</span>
              {totalImages > 0 && (
                <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full min-w-[20px] text-center">
                  {totalImages}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}