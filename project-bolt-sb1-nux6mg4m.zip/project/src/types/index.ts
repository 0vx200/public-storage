export interface Network {
  name: string;
  chainId: number;
  rpcUrl: string;
  explorerUrl: string;
  parentChain: string;
  logoUrl: string;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
  contracts: {
    WETH: {
      address: string;
      symbol: string;
      name: string;
      decimals: number;
    };
    FACTORY: {
      address: string;
    };
    ROUTER: {
      address: string;
    };
  };
}

export interface Token {
  address: string;
  name: string;
  symbol: string;
  logoURI: string;
  decimals: number;
  chainId: number;
  isNative?: boolean;
}

export interface SwapQuote {
  amountOut: string;
  path: string[];
  priceImpact: number;
  minAmountOut: string;
}

export interface LiquidityPosition {
  tokenA: Token;
  tokenB: Token;
  liquidityTokens: string;
  share: number;
}