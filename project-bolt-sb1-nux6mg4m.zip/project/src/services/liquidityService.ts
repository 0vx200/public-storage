import { Contract, formatUnits, parseUnits, JsonRpcProvider, BrowserProvider } from 'ethers';
import { Network, Token } from '../types';
import { ROUTER_ABI, ERC20_ABI, FACTORY_ABI } from '../config/abis';

interface LiquidityPosition {
  tokenA: Token;
  tokenB: Token;
  liquidityTokens: string;
  share: number;
  reserveA: string;
  reserveB: string;
  pairAddress: string;
}

// Simple pair ABI for getting reserves
const PAIR_ABI = [
  {
    "inputs": [],
    "name": "getReserves",
    "outputs": [
      {"internalType": "uint112", "name": "_reserve0", "type": "uint112"},
      {"internalType": "uint112", "name": "_reserve1", "type": "uint112"},
      {"internalType": "uint32", "name": "_blockTimestampLast", "type": "uint32"}
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "address", "name": "", "type": "address"}],
    "name": "balanceOf",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "token0",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "token1",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "address", "name": "owner", "type": "address"},
      {"internalType": "address", "name": "spender", "type": "address"}
    ],
    "name": "allowance",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {"internalType": "address", "name": "spender", "type": "address"},
      {"internalType": "uint256", "name": "amount", "type": "uint256"}
    ],
    "name": "approve",
    "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

export class LiquidityService {
  private provider: JsonRpcProvider | BrowserProvider;
  private network: Network;

  constructor(network: Network, provider?: BrowserProvider) {
    this.network = network;
    this.provider = provider || new JsonRpcProvider(network.rpcUrl);
  }

  private getRouterContract(signer?: any) {
    return new Contract(
      this.network.contracts.ROUTER.address,
      ROUTER_ABI,
      signer || this.provider
    );
  }

  private getFactoryContract(signer?: any) {
    return new Contract(
      this.network.contracts.FACTORY.address,
      FACTORY_ABI,
      signer || this.provider
    );
  }

  private getTokenContract(tokenAddress: string, signer?: any) {
    return new Contract(tokenAddress, ERC20_ABI, signer || this.provider);
  }

  private getPairContract(pairAddress: string, signer?: any) {
    return new Contract(pairAddress, PAIR_ABI, signer || this.provider);
  }

  // Safe parsing with overflow protection
  private safeParseUnits(amount: string, decimals: number): bigint {
    try {
      const num = Number(amount);
      if (num === 0 || !isFinite(num)) return BigInt(0);
      
      // Prevent overflow by limiting precision
      const maxSafeValue = Number.MAX_SAFE_INTEGER / Math.pow(10, decimals);
      if (num > maxSafeValue) {
        console.warn('Amount too large, capping to safe value:', amount);
        return parseUnits(maxSafeValue.toString(), decimals);
      }
      
      // Use fixed precision to avoid scientific notation
      const fixedAmount = num.toFixed(Math.min(decimals, 18));
      const cleanAmount = fixedAmount.replace(/\.?0+$/, '');
      
      if (!cleanAmount || cleanAmount === '.') return BigInt(0);
      
      return parseUnits(cleanAmount, decimals);
    } catch (error) {
      console.error('Error parsing units:', error, 'Amount:', amount, 'Decimals:', decimals);
      return BigInt(0);
    }
  }

  // Safe formatting with precision control
  private safeFormatUnits(value: bigint, decimals: number, maxDecimals: number = 6): string {
    try {
      const formatted = formatUnits(value, decimals);
      const num = Number(formatted);
      
      if (!isFinite(num)) return '0';
      
      // Limit decimal places to prevent UI overflow
      return num.toFixed(Math.min(maxDecimals, decimals));
    } catch (error) {
      console.error('Error formatting units:', error);
      return '0';
    }
  }

  private normalizeAddress(address: string): string {
    if (address === 'ETH') return address;
    return address.toLowerCase();
  }

  async getUserLiquidityPositions(userAddress: string, availableTokens: Token[]): Promise<LiquidityPosition[]> {
    try {
      console.log('=== 🚀 Starting Liquidity Position Detection ===');
      console.log('👤 User address:', userAddress);
      console.log('🌐 Network:', this.network.name, 'Chain ID:', this.network.chainId);
      
      const positions: LiquidityPosition[] = [];
      const factoryContract = this.getFactoryContract();
      
      try {
        // Get total number of pairs from factory
        const allPairsLength = await factoryContract.allPairsLength();
        console.log('📊 Total pairs in factory:', allPairsLength.toString());
        
        // Check recent pairs first (more likely to have user liquidity)
        const maxPairsToCheck = Math.min(100, Number(allPairsLength));
        const startIndex = Math.max(0, Number(allPairsLength) - maxPairsToCheck);
        
        console.log(`🔍 Checking ${maxPairsToCheck} most recent pairs`);
        
        // Check pairs in reverse order (newest first)
        for (let i = Number(allPairsLength) - 1; i >= startIndex; i--) {
          try {
            const pairAddress = await factoryContract.allPairs(i);
            
            if (pairAddress === '0x0000000000000000000000000000000000000000') {
              continue;
            }
            
            const pairContract = this.getPairContract(pairAddress);
            
            // Get user's LP token balance for this pair
            const lpBalance = await pairContract.balanceOf(userAddress);
            
            if (lpBalance > 0) {
              console.log('✅ Found LP tokens! Getting pair details...');
              
              // Get token addresses from the pair
              const [token0Address, token1Address, reserves, totalSupply] = await Promise.all([
                pairContract.token0(),
                pairContract.token1(),
                pairContract.getReserves(),
                pairContract.totalSupply()
              ]);
              
              // Try to find matching tokens in our available tokens list
              let tokenA: Token | null = null;
              let tokenB: Token | null = null;
              
              // Check if tokens are WETH (native ETH)
              const wethAddress = this.network.contracts.WETH.address.toLowerCase();
              
              for (const token of availableTokens) {
                const tokenAddress = token.isNative ? wethAddress : token.address.toLowerCase();
                
                if (tokenAddress === token0Address.toLowerCase()) {
                  tokenA = token;
                } else if (tokenAddress === token1Address.toLowerCase()) {
                  tokenB = token;
                }
              }
              
              // If we couldn't find tokens in our list, try to get their info from contracts
              if (!tokenA) {
                if (token0Address.toLowerCase() === wethAddress) {
                  tokenA = availableTokens.find(t => t.isNative) || null;
                } else {
                  // Create basic token info for unknown tokens
                  try {
                    const tokenContract = this.getTokenContract(token0Address);
                    const [symbol, name, decimals] = await Promise.all([
                      tokenContract.symbol().catch(() => 'UNKNOWN'),
                      tokenContract.name().catch(() => 'Unknown Token'),
                      tokenContract.decimals().catch(() => 18)
                    ]);
                    
                    tokenA = {
                      address: token0Address,
                      name: name,
                      symbol: symbol,
                      logoURI: `https://via.placeholder.com/32x32/06b6d4/ffffff?text=${symbol.charAt(0)}`,
                      decimals: Number(decimals),
                      chainId: this.network.chainId,
                      isNative: false
                    };
                  } catch (error) {
                    console.warn('Failed to get token0 info:', error);
                  }
                }
              }
              
              if (!tokenB) {
                if (token1Address.toLowerCase() === wethAddress) {
                  tokenB = availableTokens.find(t => t.isNative) || null;
                } else {
                  // Create basic token info for unknown tokens
                  try {
                    const tokenContract = this.getTokenContract(token1Address);
                    const [symbol, name, decimals] = await Promise.all([
                      tokenContract.symbol().catch(() => 'UNKNOWN'),
                      tokenContract.name().catch(() => 'Unknown Token'),
                      tokenContract.decimals().catch(() => 18)
                    ]);
                    
                    tokenB = {
                      address: token1Address,
                      name: name,
                      symbol: symbol,
                      logoURI: `https://via.placeholder.com/32x32/06b6d4/ffffff?text=${symbol.charAt(0)}`,
                      decimals: Number(decimals),
                      chainId: this.network.chainId,
                      isNative: false
                    };
                  } catch (error) {
                    console.warn('Failed to get token1 info:', error);
                  }
                }
              }
              
              if (tokenA && tokenB) {
                console.log('✅ Both tokens identified:', tokenA.symbol, tokenB.symbol);
                
                // Calculate user's share with safe math
                const lpBalanceFormatted = this.safeFormatUnits(lpBalance, 18);
                const totalSupplyFormatted = this.safeFormatUnits(totalSupply, 18);
                
                const share = totalSupplyFormatted !== '0' 
                  ? (Number(lpBalanceFormatted) / Number(totalSupplyFormatted)) * 100 
                  : 0;
                
                // Calculate user's underlying token amounts with safe formatting
                const reserve0Formatted = this.safeFormatUnits(reserves._reserve0, tokenA.decimals);
                const reserve1Formatted = this.safeFormatUnits(reserves._reserve1, tokenB.decimals);
                
                const userReserveA = (parseFloat(reserve0Formatted) * share / 100).toString();
                const userReserveB = (parseFloat(reserve1Formatted) * share / 100).toString();
                
                const position = {
                  tokenA,
                  tokenB,
                  liquidityTokens: lpBalanceFormatted,
                  share,
                  reserveA: userReserveA,
                  reserveB: userReserveB,
                  pairAddress
                };
                
                positions.push(position);
                console.log('✅ Position added:', position);
              }
            }
          } catch (error) {
            console.log(`❌ Error checking pair ${i}:`, error.message);
            continue;
          }
        }
      } catch (error) {
        console.error('Error getting pairs from factory:', error);
      }
      
      console.log('\n=== 📊 Final Results ===');
      console.log('🎉 Total positions found:', positions.length);
      
      return positions;
    } catch (error) {
      console.error('💥 Critical error in liquidity position detection:', error);
      return [];
    }
  }

  async checkLPTokenAllowance(
    pairAddress: string,
    ownerAddress: string,
    spenderAddress: string
  ): Promise<string> {
    try {
      const pairContract = this.getPairContract(pairAddress);
      const allowance = await pairContract.allowance(ownerAddress, spenderAddress);
      return this.safeFormatUnits(allowance, 18);
    } catch (error) {
      console.error('Error checking LP token allowance:', error);
      return '0';
    }
  }

  async approveLPTokens(
    pairAddress: string,
    spenderAddress: string,
    amount: string,
    signer: any
  ): Promise<any> {
    try {
      const pairContract = this.getPairContract(pairAddress, signer);
      const amountWei = this.safeParseUnits(amount, 18); // LP tokens are always 18 decimals
      const tx = await pairContract.approve(spenderAddress, amountWei);
      return tx;
    } catch (error) {
      console.error('Error approving LP tokens:', error);
      throw error;
    }
  }

  async removeLiquidity(
    tokenA: Token,
    tokenB: Token,
    liquidity: string,
    minAmountA: string,
    minAmountB: string,
    userAddress: string,
    signer: any
  ): Promise<any> {
    try {
      const routerContract = this.getRouterContract(signer);
      const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes

      // Use safe parsing with overflow protection
      const liquidityWei = this.safeParseUnits(liquidity, 18);
      const minAmountAWei = this.safeParseUnits(minAmountA, tokenA.decimals);
      const minAmountBWei = this.safeParseUnits(minAmountB, tokenB.decimals);

      console.log('Remove liquidity params (safe):', {
        liquidityWei: liquidityWei.toString(),
        minAmountAWei: minAmountAWei.toString(),
        minAmountBWei: minAmountBWei.toString(),
        tokenA: tokenA.symbol,
        tokenB: tokenB.symbol
      });

      // Validate amounts to prevent overflow
      if (liquidityWei === BigInt(0)) {
        throw new Error('Liquidity amount cannot be zero');
      }

      let tx;

      if (tokenA.isNative || tokenB.isNative) {
        const token = tokenA.isNative ? tokenB : tokenA;
        const minAmountToken = tokenA.isNative ? minAmountBWei : minAmountAWei;
        const minAmountETH = tokenA.isNative ? minAmountAWei : minAmountBWei;

        // Additional validation for ETH pairs
        if (minAmountETH === BigInt(0) || minAmountToken === BigInt(0)) {
          throw new Error('Minimum amounts cannot be zero');
        }

        tx = await routerContract.removeLiquidityETH(
          this.normalizeAddress(token.address),
          liquidityWei,
          minAmountToken,
          minAmountETH,
          userAddress,
          deadline
        );
      } else {
        // Additional validation for token pairs
        if (minAmountAWei === BigInt(0) || minAmountBWei === BigInt(0)) {
          throw new Error('Minimum amounts cannot be zero');
        }

        tx = await routerContract.removeLiquidity(
          this.normalizeAddress(tokenA.address),
          this.normalizeAddress(tokenB.address),
          liquidityWei,
          minAmountAWei,
          minAmountBWei,
          userAddress,
          deadline
        );
      }

      return tx;
    } catch (error) {
      console.error('Error removing liquidity:', error);
      
      // Provide more specific error messages
      if (error.message.includes('OVERFLOW')) {
        throw new Error('Amount too large. Please try a smaller percentage.');
      } else if (error.message.includes('INSUFFICIENT_LIQUIDITY')) {
        throw new Error('Insufficient liquidity in the pool.');
      } else if (error.message.includes('TRANSFER_FROM_FAILED')) {
        throw new Error('LP token transfer failed. Please check your allowance.');
      }
      
      throw error;
    }
  }

  async addLiquidity(
    tokenA: Token,
    tokenB: Token,
    amountA: string,
    amountB: string,
    minAmountA: string,
    minAmountB: string,
    userAddress: string,
    signer: any
  ): Promise<any> {
    try {
      const routerContract = this.getRouterContract(signer);
      const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes

      // Use safe parsing to avoid overflow issues
      const amountAWei = this.safeParseUnits(amountA, tokenA.decimals);
      const amountBWei = this.safeParseUnits(amountB, tokenB.decimals);
      const minAmountAWei = this.safeParseUnits(minAmountA, tokenA.decimals);
      const minAmountBWei = this.safeParseUnits(minAmountB, tokenB.decimals);

      let tx;

      if (tokenA.isNative || tokenB.isNative) {
        const token = tokenA.isNative ? tokenB : tokenA;
        const amountToken = tokenA.isNative ? amountBWei : amountAWei;
        const amountETH = tokenA.isNative ? amountAWei : amountBWei;
        const minAmountToken = tokenA.isNative ? minAmountBWei : minAmountAWei;
        const minAmountETH = tokenA.isNative ? minAmountAWei : minAmountBWei;

        tx = await routerContract.addLiquidityETH(
          this.normalizeAddress(token.address),
          amountToken,
          minAmountToken,
          minAmountETH,
          userAddress,
          deadline,
          { value: amountETH }
        );
      } else {
        tx = await routerContract.addLiquidity(
          this.normalizeAddress(tokenA.address),
          this.normalizeAddress(tokenB.address),
          amountAWei,
          amountBWei,
          minAmountAWei,
          minAmountBWei,
          userAddress,
          deadline
        );
      }

      return tx;
    } catch (error) {
      console.error('Error adding liquidity:', error);
      throw error;
    }
  }
}