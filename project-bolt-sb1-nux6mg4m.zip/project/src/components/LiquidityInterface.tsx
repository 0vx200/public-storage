import React, { useState, useEffect } from 'react';
import { Plus, Minus, ChevronDown, Info, RefreshCw, CheckCircle, XCircle, Loader, ExternalLink } from 'lucide-react';
import { Token, Network } from '../types';
import { TokenSelector } from './TokenSelector';
import { ContractService } from '../services/contractService';
import { LiquidityService } from '../services/liquidityService';
import { useWallet } from '../hooks/useWallet';
import { getTokensForChain } from '../config/tokens';

interface LiquidityInterfaceProps {
  currentNetwork: Network;
}

interface LiquidityPosition {
  tokenA: Token;
  tokenB: Token;
  liquidityTokens: string;
  share: number;
  reserveA: string;
  reserveB: string;
  pairAddress: string;
}

type TransactionStatus = 'idle' | 'pending' | 'success' | 'error';

interface TransactionState {
  status: TransactionStatus;
  message: string;
  hash?: string;
}

// Compact token logo component with fixed size
const TokenLogo = ({ token, className = "w-6 h-6" }: { token: Token; className?: string }) => {
  const [hasError, setHasError] = useState(false);
  
  const generateStableLogo = (symbol: string) => {
    if (!symbol || symbol.trim() === '') return 'T';
    return symbol.trim().charAt(0).toUpperCase();
  };

  return (
    <div className={`${className} rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold flex-shrink-0 border border-slate-700`}>
      {!hasError && token.logoURI && !token.logoURI.includes('via.placeholder.com') ? (
        <img
          src={token.logoURI}
          alt={token.symbol}
          className={`${className} rounded-full object-cover`}
          onError={() => setHasError(true)}
          onLoad={() => setHasError(false)}
        />
      ) : (
        <span className="text-xs font-bold">
          {generateStableLogo(token.symbol)}
        </span>
      )}
    </div>
  );
};

export function LiquidityInterface({ currentNetwork }: LiquidityInterfaceProps) {
  const { isConnected, address, signer, provider } = useWallet();
  const [tokens, setTokens] = useState<Token[]>([]);
  const [tokenA, setTokenA] = useState<Token | null>(null);
  const [tokenB, setTokenB] = useState<Token | null>(null);
  const [amountA, setAmountA] = useState('');
  const [amountB, setAmountB] = useState('');
  const [showTokenASelector, setShowTokenASelector] = useState(false);
  const [showTokenBSelector, setShowTokenBSelector] = useState(false);
  const [balanceA, setBalanceA] = useState('0');
  const [balanceB, setBalanceB] = useState('0');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'add' | 'remove'>('add');
  const [contractService, setContractService] = useState<ContractService | null>(null);
  const [liquidityService, setLiquidityService] = useState<LiquidityService | null>(null);
  
  // Remove liquidity states
  const [liquidityPositions, setLiquidityPositions] = useState<LiquidityPosition[]>([]);
  const [selectedPosition, setSelectedPosition] = useState<LiquidityPosition | null>(null);
  const [removePercentage, setRemovePercentage] = useState(25);
  const [isUpdatingRatio, setIsUpdatingRatio] = useState(false);
  const [isLoadingPositions, setIsLoadingPositions] = useState(false);
  const [transaction, setTransaction] = useState<TransactionState>({ status: 'idle', message: '' });
  const [showManualSelection, setShowManualSelection] = useState(false);

  // Initialize tokens and services when network changes
  useEffect(() => {
    console.log('LiquidityInterface: Network changed to', currentNetwork.name);
    const newTokens = getTokensForChain(currentNetwork.chainId);
    setTokens(newTokens);
    setTokenA(newTokens[0] || null);
    setTokenB(newTokens[1] || null);
    setAmountA('');
    setAmountB('');
    setBalanceA('0');
    setBalanceB('0');
    setLiquidityPositions([]);
    setSelectedPosition(null);
    setTransaction({ status: 'idle', message: '' });
    setShowManualSelection(false);
    
    // Create new services for the current network
    const newContractService = new ContractService(currentNetwork, provider);
    const newLiquidityService = new LiquidityService(currentNetwork, provider);
    setContractService(newContractService);
    setLiquidityService(newLiquidityService);
  }, [currentNetwork.chainId, provider]);

  // Update balances when wallet or tokens change
  useEffect(() => {
    if (isConnected && address && tokenA && contractService) {
      contractService.getTokenBalance(tokenA.address, address)
        .then(balance => setBalanceA(balance))
        .catch(error => {
          console.error('Error fetching tokenA balance:', error);
          setBalanceA('0');
        });
    } else {
      setBalanceA('0');
    }
  }, [isConnected, address, tokenA, contractService]);

  useEffect(() => {
    if (isConnected && address && tokenB && contractService) {
      contractService.getTokenBalance(tokenB.address, address)
        .then(balance => setBalanceB(balance))
        .catch(error => {
          console.error('Error fetching tokenB balance:', error);
          setBalanceB('0');
        });
    } else {
      setBalanceB('0');
    }
  }, [isConnected, address, tokenB, contractService]);

  // Load liquidity positions when in remove mode
  useEffect(() => {
    if (mode === 'remove' && isConnected && address && liquidityService && tokens.length > 0) {
      loadLiquidityPositions();
    }
  }, [mode, isConnected, address, liquidityService, tokens]);

  // Auto-calculate ratio when amountA changes
  useEffect(() => {
    if (amountA && tokenA && tokenB && contractService && !isUpdatingRatio && mode === 'add') {
      calculateRatio('A');
    }
  }, [amountA, tokenA, tokenB, contractService, mode]);

  // Auto-calculate ratio when amountB changes
  useEffect(() => {
    if (amountB && tokenA && tokenB && contractService && !isUpdatingRatio && mode === 'add') {
      calculateRatio('B');
    }
  }, [amountB, tokenA, tokenB, contractService, mode]);

  const calculateRatio = async (changedToken: 'A' | 'B') => {
    if (!tokenA || !tokenB || !contractService) return;

    try {
      setIsUpdatingRatio(true);
      
      // Get pair reserves to calculate ratio
      const pairReserves = await contractService.getPairReserves(tokenA, tokenB);
      
      if (pairReserves && pairReserves.reserveA !== '0' && pairReserves.reserveB !== '0') {
        const reserveA = parseFloat(pairReserves.reserveA);
        const reserveB = parseFloat(pairReserves.reserveB);
        const ratio = reserveA / reserveB;

        if (changedToken === 'A' && amountA) {
          const calculatedB = (parseFloat(amountA) / ratio).toFixed(6);
          setAmountB(calculatedB);
        } else if (changedToken === 'B' && amountB) {
          const calculatedA = (parseFloat(amountB) * ratio).toFixed(6);
          setAmountA(calculatedA);
        }
      }
    } catch (error) {
      console.log('No existing pair found or error calculating ratio:', error);
    } finally {
      setIsUpdatingRatio(false);
    }
  };

  const loadLiquidityPositions = async () => {
    if (!liquidityService || !address || tokens.length === 0) return;

    try {
      setIsLoadingPositions(true);
      console.log('Loading liquidity positions for:', address);
      
      const positions = await liquidityService.getUserLiquidityPositions(address, tokens);
      console.log('Found positions:', positions);
      
      setLiquidityPositions(positions);
      if (positions.length > 0) {
        setSelectedPosition(positions[0]);
      } else {
        setSelectedPosition(null);
      }
    } catch (error) {
      console.error('Error loading liquidity positions:', error);
      setLiquidityPositions([]);
      setSelectedPosition(null);
    } finally {
      setIsLoadingPositions(false);
    }
  };

  const handleSelectPosition = (position: LiquidityPosition) => {
    setSelectedPosition(position);
    setTokenA(position.tokenA);
    setTokenB(position.tokenB);
    setShowManualSelection(false);
  };

  const resetSelection = () => {
    setSelectedPosition(null);
    setTokenA(tokens[0] || null);
    setTokenB(tokens[1] || null);
    setShowManualSelection(false);
  };

  const handleMaxClickA = () => {
    if (tokenA?.isNative) {
      const maxAmount = Math.max(0, parseFloat(balanceA) - 0.01);
      setAmountA(maxAmount.toString());
    } else {
      setAmountA(balanceA);
    }
  };

  const handleMaxClickB = () => {
    if (tokenB?.isNative) {
      const maxAmount = Math.max(0, parseFloat(balanceB) - 0.01);
      setAmountB(maxAmount.toString());
    } else {
      setAmountB(balanceB);
    }
  };

  const handleAddLiquidity = async () => {
    if (!isConnected || !signer || !tokenA || !tokenB || !address || !liquidityService) {
      setTransaction({ status: 'error', message: 'Please connect your wallet and ensure all fields are filled' });
      return;
    }

    if (!amountA || !amountB || parseFloat(amountA) <= 0 || parseFloat(amountB) <= 0) {
      setTransaction({ status: 'error', message: 'Please enter valid amounts for both tokens' });
      return;
    }

    try {
      setIsLoading(true);
      setTransaction({ status: 'pending', message: 'Preparing to add liquidity...' });

      // Check token approvals
      if (!tokenA.isNative && contractService) {
        setTransaction({ status: 'pending', message: 'Checking Token A approval...' });
        const allowanceA = await contractService.getTokenAllowance(
          tokenA.address,
          address,
          currentNetwork.contracts.ROUTER.address,
          tokenA.decimals
        );

        if (parseFloat(allowanceA) < parseFloat(amountA)) {
          setTransaction({ status: 'pending', message: 'Approving Token A...' });
          const approveTx = await contractService.approveToken(
            tokenA.address,
            currentNetwork.contracts.ROUTER.address,
            amountA,
            tokenA.decimals,
            signer
          );
          setTransaction({ status: 'pending', message: 'Waiting for Token A approval...', hash: approveTx.hash });
          await approveTx.wait();
        }
      }

      if (!tokenB.isNative && contractService) {
        setTransaction({ status: 'pending', message: 'Checking Token B approval...' });
        const allowanceB = await contractService.getTokenAllowance(
          tokenB.address,
          address,
          currentNetwork.contracts.ROUTER.address,
          tokenB.decimals
        );

        if (parseFloat(allowanceB) < parseFloat(amountB)) {
          setTransaction({ status: 'pending', message: 'Approving Token B...' });
          const approveTx = await contractService.approveToken(
            tokenB.address,
            currentNetwork.contracts.ROUTER.address,
            amountB,
            tokenB.decimals,
            signer
          );
          setTransaction({ status: 'pending', message: 'Waiting for Token B approval...', hash: approveTx.hash });
          await approveTx.wait();
        }
      }

      // Calculate minimum amounts (5% slippage)
      const minAmountA = (parseFloat(amountA) * 0.95).toString();
      const minAmountB = (parseFloat(amountB) * 0.95).toString();

      setTransaction({ status: 'pending', message: 'Adding liquidity...' });
      const tx = await liquidityService.addLiquidity(
        tokenA,
        tokenB,
        amountA,
        amountB,
        minAmountA,
        minAmountB,
        address,
        signer
      );

      setTransaction({ status: 'pending', message: 'Waiting for confirmation...', hash: tx.hash });
      await tx.wait();
      setTransaction({ status: 'success', message: 'Liquidity added successfully!', hash: tx.hash });

      // Refresh balances and positions
      if (address && contractService) {
        contractService.getTokenBalance(tokenA.address, address).then(setBalanceA);
        contractService.getTokenBalance(tokenB.address, address).then(setBalanceB);
        
        // Reload positions if we're in remove mode
        if (mode === 'remove') {
          loadLiquidityPositions();
        }
      }

      setAmountA('');
      setAmountB('');

      // Clear success message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } catch (error: any) {
      console.error('Add liquidity failed:', error);
      setTransaction({ status: 'error', message: `Add liquidity failed: ${error.message}` });
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveLiquidity = async () => {
    if (!isConnected || !signer || !selectedPosition || !address || !liquidityService) {
      setTransaction({ status: 'error', message: 'Please connect your wallet and select a liquidity position' });
      return;
    }

    try {
      setIsLoading(true);
      setTransaction({ status: 'pending', message: 'Preparing to remove liquidity...' });

      // Calculate liquidity to remove with safe math
      const liquidityToRemove = (parseFloat(selectedPosition.liquidityTokens) * removePercentage / 100).toFixed(18);
      
      // Check LP token allowance
      const allowance = await liquidityService.checkLPTokenAllowance(
        selectedPosition.pairAddress,
        address,
        currentNetwork.contracts.ROUTER.address
      );

      if (parseFloat(allowance) < parseFloat(liquidityToRemove)) {
        setTransaction({ status: 'pending', message: 'Approving LP tokens...' });
        const approveTx = await liquidityService.approveLPTokens(
          selectedPosition.pairAddress,
          currentNetwork.contracts.ROUTER.address,
          liquidityToRemove,
          signer
        );
        setTransaction({ status: 'pending', message: 'Waiting for LP token approval...', hash: approveTx.hash });
        await approveTx.wait();
      }

      // Calculate minimum amounts with safe math (5% slippage)
      const minAmountA = (parseFloat(selectedPosition.reserveA) * removePercentage / 100 * 0.95).toFixed(selectedPosition.tokenA.decimals);
      const minAmountB = (parseFloat(selectedPosition.reserveB) * removePercentage / 100 * 0.95).toFixed(selectedPosition.tokenB.decimals);

      setTransaction({ status: 'pending', message: 'Removing liquidity...' });
      const tx = await liquidityService.removeLiquidity(
        selectedPosition.tokenA,
        selectedPosition.tokenB,
        liquidityToRemove,
        minAmountA,
        minAmountB,
        address,
        signer
      );

      setTransaction({ status: 'pending', message: 'Waiting for confirmation...', hash: tx.hash });
      await tx.wait();
      setTransaction({ status: 'success', message: 'Liquidity removed successfully!', hash: tx.hash });

      // Refresh positions and balances
      await loadLiquidityPositions();
      if (address && contractService) {
        contractService.getTokenBalance(selectedPosition.tokenA.address, address).then(setBalanceA);
        contractService.getTokenBalance(selectedPosition.tokenB.address, address).then(setBalanceB);
      }

      // Clear success message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } catch (error: any) {
      console.error('Remove liquidity failed:', error);
      setTransaction({ status: 'error', message: `Remove liquidity failed: ${error.message}` });
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setTransaction({ status: 'idle', message: '' });
      }, 5000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTokenASelect = (token: Token) => {
    setTokenA(token);
    // Add to tokens list if it's a custom token
    if (!tokens.find(t => t.address.toLowerCase() === token.address.toLowerCase())) {
      setTokens(prev => [...prev, token]);
    }
  };

  const handleTokenBSelect = (token: Token) => {
    setTokenB(token);
    // Add to tokens list if it's a custom token
    if (!tokens.find(t => t.address.toLowerCase() === token.address.toLowerCase())) {
      setTokens(prev => [...prev, token]);
    }
  };

  const formatBalance = (balance: string, decimals = 18) => {
    if (!balance || balance === "0") return "0";
    return Number(balance).toLocaleString(undefined, {
      maximumFractionDigits: 6,
    });
  };

  // Show loading state while initializing
  if (!contractService || !liquidityService || tokens.length === 0) {
    return (
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-600/50 p-4 sm:p-6 w-full">
        <div className="flex items-center justify-center py-12">
          <div className="text-slate-400">Loading liquidity interface...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-600/50 p-4 sm:p-6 w-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-white">Liquidity</h2>
        <div className="flex bg-slate-700/50 rounded-lg p-1">
          <button
            onClick={() => setMode('add')}
            className={`px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-colors ${
              mode === 'add'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plus className="w-3 h-3 sm:w-4 sm:h-4 inline-block mr-1" />
            Add
          </button>
          <button
            onClick={() => setMode('remove')}
            className={`px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-colors ${
              mode === 'remove'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Minus className="w-3 h-3 sm:w-4 sm:h-4 inline-block mr-1" />
            Remove
          </button>
        </div>
      </div>

      {/* Transaction Status */}
      {transaction.status !== 'idle' && (
        <div className={`mb-4 p-3 sm:p-4 rounded-xl border ${
          transaction.status === 'success' 
            ? 'border-green-500/30 bg-green-500/10' 
            : transaction.status === 'error'
            ? 'border-red-500/30 bg-red-500/10'
            : 'border-cyan-500/30 bg-cyan-500/10'
        }`}>
          <div className="flex items-center space-x-3">
            {transaction.status === 'pending' && <Loader className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-cyan-400" />}
            {transaction.status === 'success' && <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />}
            {transaction.status === 'error' && <XCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-400" />}
            <div className="flex-1">
              <p className={`text-xs sm:text-sm font-medium ${
                transaction.status === 'success' 
                  ? 'text-green-300' 
                  : transaction.status === 'error'
                  ? 'text-red-300'
                  : 'text-cyan-300'
              }`}>
                {transaction.message}
              </p>
              {transaction.hash && (
                <a
                  href={`${currentNetwork.explorerUrl}/tx/${transaction.hash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs underline mt-1 block text-cyan-400 hover:text-cyan-300"
                >
                  View transaction
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {mode === 'add' && (
        <div className="space-y-4">
          {/* Ratio Info */}
          <div className="rounded-lg p-3 mb-4 border bg-cyan-500/10 border-cyan-500/30">
            <div className="flex items-center space-x-2 text-cyan-300">
              <Info className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="text-xs sm:text-sm font-medium">Auto-ratio calculation</span>
            </div>
            <p className="text-xs mt-1 text-cyan-200/80">
              Amounts will automatically adjust to match existing pool ratio
            </p>
          </div>

          {/* Token A */}
          <div className="bg-slate-700/30 rounded-xl p-3 sm:p-4 border border-slate-600/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm text-slate-400">Token A</span>
              {isConnected && (
                <span className="text-xs sm:text-sm text-slate-400">
                  Balance: {parseFloat(balanceA).toFixed(4)} {tokenA?.symbol}
                </span>
              )}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex-1 mr-3 sm:mr-4">
                <input
                  type="number"
                  value={amountA}
                  onChange={(e) => setAmountA(e.target.value)}
                  placeholder="0.0"
                  className="w-full bg-transparent text-lg sm:text-xl font-semibold text-white placeholder-slate-500 focus:outline-none"
                />
                {isConnected && tokenA && (
                  <button
                    onClick={handleMaxClickA}
                    className="text-xs sm:text-sm font-medium mt-1 hover:underline text-cyan-400 hover:text-cyan-300"
                  >
                    MAX
                  </button>
                )}
              </div>
              <button
                onClick={() => setShowTokenASelector(true)}
                className="flex items-center space-x-2 sm:space-x-3 bg-slate-600/50 hover:bg-slate-600/70 transition-all duration-200 px-3 sm:px-4 py-2 sm:py-3 rounded-xl border border-slate-500/50 shadow-sm hover:shadow-md min-w-[100px] sm:min-w-[120px]"
              >
                {tokenA ? (
                  <>
                    <TokenLogo token={tokenA} />
                    <div className="flex flex-col items-start">
                      <span className="font-semibold text-white text-xs sm:text-sm">{tokenA.symbol}</span>
                    </div>
                    <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                  </>
                ) : (
                  <>
                    <div className="w-6 h-6 bg-slate-600 rounded-full flex-shrink-0"></div>
                    <span className="text-slate-400 font-medium text-xs sm:text-sm">Select</span>
                    <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Plus Icon */}
          <div className="flex justify-center">
            <div className="p-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500">
              <Plus className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
          </div>

          {/* Token B */}
          <div className="bg-slate-700/30 rounded-xl p-3 sm:p-4 border border-slate-600/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm text-slate-400">Token B</span>
              {isConnected && (
                <span className="text-xs sm:text-sm text-slate-400">
                  Balance: {parseFloat(balanceB).toFixed(4)} {tokenB?.symbol}
                </span>
              )}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex-1 mr-3 sm:mr-4">
                <input
                  type="number"
                  value={amountB}
                  onChange={(e) => setAmountB(e.target.value)}
                  placeholder="0.0"
                  className="w-full bg-transparent text-lg sm:text-xl font-semibold text-white placeholder-slate-500 focus:outline-none"
                />
                {isConnected && tokenB && (
                  <button
                    onClick={handleMaxClickB}
                    className="text-xs sm:text-sm font-medium mt-1 hover:underline text-cyan-400 hover:text-cyan-300"
                  >
                    MAX
                  </button>
                )}
              </div>
              <button
                onClick={() => setShowTokenBSelector(true)}
                className="flex items-center space-x-2 sm:space-x-3 bg-slate-600/50 hover:bg-slate-600/70 transition-all duration-200 px-3 sm:px-4 py-2 sm:py-3 rounded-xl border border-slate-500/50 shadow-sm hover:shadow-md min-w-[100px] sm:min-w-[120px]"
              >
                {tokenB ? (
                  <>
                    <TokenLogo token={tokenB} />
                    <div className="flex flex-col items-start">
                      <span className="font-semibold text-white text-xs sm:text-sm">{tokenB.symbol}</span>
                    </div>
                    <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                  </>
                ) : (
                  <>
                    <div className="w-6 h-6 bg-slate-600 rounded-full flex-shrink-0"></div>
                    <span className="text-slate-400 font-medium text-xs sm:text-sm">Select</span>
                    <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-slate-400 flex-shrink-0" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Add Liquidity Button */}
          <button
            onClick={handleAddLiquidity}
            disabled={!isConnected || !tokenA || !tokenB || !amountA || !amountB || isLoading || transaction.status === 'pending'}
            className="w-full mt-6 font-semibold py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed disabled:opacity-50 shadow-lg text-sm sm:text-base"
            style={{ 
              background: (!isConnected || !tokenA || !tokenB || !amountA || !amountB || isLoading || transaction.status === 'pending') 
                ? 'linear-gradient(135deg, #64748b, #475569)' 
                : 'linear-gradient(135deg, #06b6d4, #3b82f6)',
              color: 'white'
            }}
          >
            {!isConnected
              ? 'Connect Wallet'
              : transaction.status === 'pending'
              ? 'Processing...'
              : isLoading
              ? 'Adding Liquidity...'
              : !tokenA || !tokenB
              ? 'Select Tokens'
              : !amountA || !amountB
              ? 'Enter Amounts'
              : 'Add Liquidity'}
          </button>
        </div>
      )}

      {mode === 'remove' && (
        <div className="space-y-4">
          {/* Network Info */}
          <div className="bg-slate-700/30 rounded-lg p-3 mb-4 border border-slate-600/30">
            <div className="flex items-center space-x-2 text-slate-300">
              <Info className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="text-xs sm:text-sm font-medium">Network: {currentNetwork.name}</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Showing liquidity positions for {currentNetwork.name} network only
            </p>
          </div>

          {!isConnected ? (
            <div className="p-4 rounded-lg border border-slate-600/30 text-center">
              <p className="mb-4 text-slate-400 text-sm">Connect your wallet to view your liquidity positions</p>
            </div>
          ) : isLoadingPositions ? (
            <div className="p-8 flex flex-col items-center justify-center">
              <Loader className="h-6 w-6 sm:h-8 sm:w-8 animate-spin mb-2 text-cyan-400" />
              <p className="text-xs sm:text-sm text-slate-400">Loading your liquidity positions...</p>
            </div>
          ) : (
            <>
              {!selectedPosition && !showManualSelection ? (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-base sm:text-lg font-medium text-white">Your Liquidity Positions</h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={loadLiquidityPositions}
                        disabled={isLoadingPositions}
                        className="flex items-center space-x-1 text-xs sm:text-sm font-medium hover:underline text-cyan-400 hover:text-cyan-300"
                      >
                        <RefreshCw className={`w-3 h-3 sm:w-4 sm:h-4 ${isLoadingPositions ? 'animate-spin' : ''}`} />
                        <span className="hidden sm:inline">Refresh</span>
                      </button>
                      <button
                        onClick={() => setShowManualSelection(true)}
                        className="text-xs sm:text-sm text-slate-400 hover:text-white font-medium"
                      >
                        Manual
                      </button>
                    </div>
                  </div>

                  {liquidityPositions.length === 0 ? (
                    <div className="text-center py-8 sm:py-12 text-slate-400">
                      <Minus className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-4 text-slate-600" />
                      <p className="text-base sm:text-lg font-medium mb-2">No liquidity positions found</p>
                      <p className="text-xs sm:text-sm">Add liquidity first to see your positions here</p>
                      <p className="text-xs text-slate-500 mt-2">
                        Make sure you're on the correct network: {currentNetwork.name}
                      </p>
                      <button
                        onClick={() => setShowManualSelection(true)}
                        className="mt-4 px-3 sm:px-4 py-2 text-white rounded-lg transition-colors bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-xs sm:text-sm"
                      >
                        Select Tokens Manually
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {liquidityPositions.map((position, index) => (
                        <div
                          key={index}
                          onClick={() => handleSelectPosition(position)}
                          className="p-3 sm:p-4 rounded-xl border border-slate-600/50 cursor-pointer transition-all hover:shadow-md bg-slate-700/30 hover:bg-slate-700/50 hover:border-cyan-500/50"
                        >
                          <div className="flex justify-between items-center">
                            <div className="flex items-center space-x-2 sm:space-x-3">
                              <div className="flex -space-x-1">
                                <TokenLogo token={position.tokenA} className="z-10" />
                                <TokenLogo token={position.tokenB} />
                              </div>
                              <div>
                                <h4 className="font-medium text-sm sm:text-base text-white">
                                  {position.tokenA.symbol}/{position.tokenB.symbol}
                                </h4>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                                    {position.share.toFixed(4)}% Pool Share
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-white text-xs sm:text-sm">{formatBalance(position.liquidityTokens)} LP</p>
                              <div className="flex items-center gap-1 text-xs hover:underline mt-1 text-cyan-400">
                                <span className="hidden sm:inline">View Details</span>
                                <ExternalLink className="h-3 w-3" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {showManualSelection && !selectedPosition && (
                    <div className="p-3 sm:p-4 rounded-lg border border-slate-600/30 mb-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-xs sm:text-sm text-slate-400">Select Pair Manually</span>
                        <button
                          onClick={() => {
                            setShowManualSelection(false);
                            resetSelection();
                          }}
                          className="text-xs sm:text-sm hover:underline text-cyan-400 hover:text-cyan-300"
                        >
                          Back
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setShowTokenASelector(true)}
                          className="flex-1 flex items-center justify-center space-x-2 p-2 sm:p-3 border border-slate-600/50 rounded-lg hover:border-slate-500/50 bg-slate-700/30"
                        >
                          {tokenA ? (
                            <>
                              <TokenLogo token={tokenA} className="w-5 h-5 sm:w-6 sm:h-6" />
                              <span className="text-white text-xs sm:text-sm">{tokenA.symbol}</span>
                            </>
                          ) : (
                            <span className="text-slate-400 text-xs sm:text-sm">Select Token A</span>
                          )}
                        </button>
                        <span className="text-slate-400">/</span>
                        <button
                          onClick={() => setShowTokenBSelector(true)}
                          className="flex-1 flex items-center justify-center space-x-2 p-2 sm:p-3 border border-slate-600/50 rounded-lg hover:border-slate-500/50 bg-slate-700/30"
                        >
                          {tokenB ? (
                            <>
                              <TokenLogo token={tokenB} className="w-5 h-5 sm:w-6 sm:h-6" />
                              <span className="text-white text-xs sm:text-sm">{tokenB.symbol}</span>
                            </>
                          ) : (
                            <span className="text-slate-400 text-xs sm:text-sm">Select Token B</span>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {selectedPosition && (
                    <>
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-base sm:text-lg font-medium text-white">
                          {selectedPosition.tokenA.symbol}/{selectedPosition.tokenB.symbol} Pool
                        </h3>
                        <button
                          onClick={resetSelection}
                          className="text-xs sm:text-sm text-slate-400 hover:text-white"
                        >
                          Back
                        </button>
                      </div>

                      <div className="p-3 sm:p-4 rounded-lg border border-slate-600/30 space-y-4 bg-slate-700/30">
                        <div className="flex justify-between">
                          <span className="text-xs sm:text-sm font-medium text-slate-300">Your Liquidity:</span>
                          <span className="text-xs sm:text-sm font-medium text-white">{formatBalance(selectedPosition.liquidityTokens)} LP Tokens</span>
                        </div>

                        <div className="space-y-3">
                          <div className="flex justify-between mb-1">
                            <span className="text-xs sm:text-sm font-medium text-slate-300">Amount to Remove:</span>
                            <span className="text-xs sm:text-sm font-medium text-cyan-400">{removePercentage}%</span>
                          </div>
                          <input
                            type="range"
                            min="1"
                            max="100"
                            value={removePercentage}
                            onChange={(e) => setRemovePercentage(parseInt(e.target.value))}
                            className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer slider"
                            style={{
                              background: `linear-gradient(to right, #06b6d4 0%, #06b6d4 ${removePercentage}%, #475569 ${removePercentage}%, #475569 100%)`
                            }}
                          />
                          <div className="flex justify-between gap-1 sm:gap-2">
                            {[25, 50, 75, 100].map((percent) => (
                              <button
                                key={percent}
                                onClick={() => setRemovePercentage(percent)}
                                className={`px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm font-medium transition-colors ${
                                  removePercentage === percent
                                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                                    : 'bg-slate-600/50 text-slate-300 hover:bg-slate-600/70'
                                }`}
                              >
                                {percent}%
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="p-3 sm:p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                          <h3 className="font-medium text-green-300 mb-2 text-sm">You will receive</h3>
                          <div className="space-y-2 text-xs sm:text-sm">
                            <div className="flex justify-between">
                              <span className="text-green-200">{selectedPosition.tokenA.symbol}:</span>
                              <span className="font-medium text-white">
                                {(parseFloat(selectedPosition.reserveA) * removePercentage / 100).toFixed(6)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-green-200">{selectedPosition.tokenB.symbol}:</span>
                              <span className="font-medium text-white">
                                {(parseFloat(selectedPosition.reserveB) * removePercentage / 100).toFixed(6)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={handleRemoveLiquidity}
                        disabled={!isConnected || isLoading || transaction.status === 'pending'}
                        className="w-full mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 disabled:from-slate-600 disabled:to-slate-700 text-white font-semibold py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed shadow-lg text-sm sm:text-base"
                      >
                        {!isConnected
                          ? 'Connect Wallet'
                          : transaction.status === 'pending'
                          ? 'Processing...'
                          : isLoading
                          ? 'Removing Liquidity...'
                          : `Remove ${removePercentage}% Liquidity`}
                      </button>
                    </>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* Token Selectors */}
      <TokenSelector
        tokens={tokens}
        selectedToken={tokenA}
        onTokenSelect={handleTokenASelect}
        isOpen={showTokenASelector}
        onClose={() => setShowTokenASelector(false)}
        title="Select Token A"
        currentNetwork={currentNetwork}
      />

      <TokenSelector
        tokens={tokens}
        selectedToken={tokenB}
        onTokenSelect={handleTokenBSelect}
        isOpen={showTokenBSelector}
        onClose={() => setShowTokenBSelector(false)}
        title="Select Token B"
        currentNetwork={currentNetwork}
      />
    </div>
  );
}