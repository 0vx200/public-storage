import React from 'react';
import { ChevronDown } from 'lucide-react';
import { Network } from '../types';

interface NetworkSelectorProps {
  currentNetwork: Network;
  networks: Network[];
  onNetworkChange: (network: Network) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function NetworkSelector({
  currentNetwork,
  networks,
  onNetworkChange,
  isOpen,
  onToggle,
}: NetworkSelectorProps) {
  return (
    <div className="relative">
      <button
        onClick={onToggle}
        className="flex items-center space-x-1 sm:space-x-2 bg-slate-800/50 hover:bg-slate-700/50 transition-colors px-2 sm:px-4 py-2 rounded-xl border border-slate-600/50 backdrop-blur-sm"
      >
        <img
          src={currentNetwork.logoUrl}
          alt={currentNetwork.name}
          className="w-5 h-5 sm:w-6 sm:h-6 rounded-full"
        />
        <span className="text-cyan-300 font-medium text-xs sm:text-sm hidden sm:inline">{currentNetwork.name}</span>
        <ChevronDown className={`w-3 h-3 sm:w-4 sm:h-4 text-cyan-300/70 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 bg-slate-800/95 backdrop-blur-sm rounded-xl shadow-xl border border-slate-600/50 min-w-[180px] sm:min-w-[200px] z-50">
          {networks.map((network) => (
            <button
              key={network.chainId}
              onClick={() => {
                onNetworkChange(network);
                onToggle();
              }}
              className={`w-full flex items-center space-x-2 sm:space-x-3 px-3 sm:px-4 py-3 hover:bg-slate-700/50 transition-colors first:rounded-t-xl last:rounded-b-xl ${
                network.chainId === currentNetwork.chainId ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-l-4 border-cyan-400' : ''
              }`}
            >
              <img
                src={network.logoUrl}
                alt={network.name}
                className="w-6 h-6 sm:w-8 sm:h-8 rounded-full flex-shrink-0"
              />
              <div className="text-left flex-1">
                <div className="font-medium text-white text-sm">{network.name}</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}